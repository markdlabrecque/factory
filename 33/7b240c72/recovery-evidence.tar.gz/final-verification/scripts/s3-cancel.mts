// S3: cancellation of the owned tick/pass process group, with real processes and the real CLI.
//  A  `factory schedule off` while alpha's pass holds a nested shell, an analysis process with its own child and a
//     detached ticket run; beta (later in the registry) must never start.
//  B  SIGTERM sent to the tick alone (the documented effect of `systemctl stop` under KillMode=process, applied by the
//     verifier because the stub does not simulate systemd), then `schedule off`.
//  C  tick killed outright (SIGKILL): its orphaned pass group stays recorded; a new tick is busy; off cancels the orphan.
// In every case: unrelated processes (own session, the verifier's own group, an unrelated node) must survive.
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { alive, bystanders, check, finish, killAll, note, readJSON, section, sleep, waitFor } from './lib.mts';
import { hold, rec, setup, startHeld } from './setup.mts';

const timeout = <T>(p: Promise<T>, ms: number) => Promise.race([p, sleep(ms).then(() => 'timeout' as const)]);

section('A: schedule off cancels the held pass tree, keeps the detached ticket run, starts no later project');
{
  const { f, roots } = setup('s3a-off', [{ name: 'alpha', script: hold() }, { name: 'beta', script: rec('beta') }]);
  const by = bystanders(f);
  const { t, pids, record } = await startHeld(f, 'S3A');
  const s = readJSON(f.p.stateJson);
  const lock = readJSON(f.p.lock);
  check('S3A.1', s.projects[roots.alpha]?.result === 'running' && s.projects[roots.alpha]?.pid === pids.pass && s.pid === t.pid && s.currentRoot === roots.alpha,
    `state.json while held: ${JSON.stringify({ pid: s.pid, currentRoot: s.currentRoot, alpha: s.projects[roots.alpha] })}`, 'current tick PID, current root and running pass PID are persisted before/at spawn');
  check('S3A.2', lock.tick.pid === t.pid && lock.pass?.pid === pids.pass && lock.pass?.root === roots.alpha, `lock ${JSON.stringify(lock)}`, 'the lock records exactly the owned tick and pass group');
  f.setUnit('factory-tick.service', { forcedActive: 'active' }); // the manager's view: a tick is running (stub state, not simulation)
  const sj = JSON.parse(f.cli(['schedule', 'status', '--json']).out);
  check('S3A.3', sj.scheduler.phase === 'running' && sj.scheduler.tickActive === true && sj.scheduler.pid === t.pid && sj.scheduler.currentRoot === roots.alpha,
    `status while running ${JSON.stringify({ phase: sj.scheduler.phase, tickActive: sj.scheduler.tickActive, pid: sj.scheduler.pid })}`, 'status shows the running tick, its PID and current project');
  f.watch({ tick: t.pid, ...pids, ...by.pids });
  const mark = f.calls().length;
  const t0 = Date.now();
  const r = f.cli(['schedule', 'off']);
  const took = Date.now() - t0;
  const calls = f.calls().slice(mark);
  const dis = calls.find((c: any) => c.argv.slice(1).join(' ') === 'disable --now factory-tick.timer');
  const stop = calls.find((c: any) => c.argv.slice(1).join(' ') === 'stop factory-tick.service');
  check('S3A.4', r.code === 0, `off exit ${r.code} after ${took} ms`, 'off completes after cancellation', r.all);
  check('S3A.5', dis && stop && dis.seq < stop.seq && dis.watch.tick && dis.watch.pass && dis.watch.analysisChild && stop.watch.tick && stop.watch.pass,
    `at 'disable --now' tick/pass alive=${dis?.watch.tick}/${dis?.watch.pass}; at 'stop service' tick/pass alive=${stop?.watch.tick}/${stop?.watch.pass}`, 'the timer is disabled+stopped FIRST, then the service stop, and only then is the tick/pass cancelled');
  const e = await timeout(t.exit, 5000);
  check('S3A.6', e !== 'timeout' && (e as any).code === 143, `tick exit ${JSON.stringify(e)}`, 'the cancelled tick reports interruption with exit 143');
  check('S3A.7', !alive(pids.pass) && !alive(pids.nested) && !alive(pids.analysis) && !alive(pids.analysisChild),
    'pass, nested shell, analysis and analysis child are all gone when off returns', 'off cancels the active pass and its non-detached nested children, and waits for that before reporting');
  check('S3A.8', alive(pids.ticket) && readFileSync(join(f.p.state, 'synthetic-alpha-1.json'), 'utf8') === record,
    `detached ticket ${pids.ticket} alive; its run record unchanged`, 'independently detached ticket runs and their records/reservations survive cancellation');
  check('S3A.9', alive(by.pids.ownSession) && alive(by.pids.verifierGroup) && alive(by.pids.unrelatedNode), 'bystanders (own session, verifier group, unrelated node) alive', 'cancellation is confined to the owned group: no broad/name-based kill');
  const st = readJSON(f.p.stateJson);
  const a = st.projects[roots.alpha];
  check('S3A.10', a.result === 'interrupted' && a.pid === pids.pass && st.pid === undefined && st.currentRoot === undefined && st.finishedAt,
    `state.json alpha ${JSON.stringify(a)}`, 'the cancelled pass is recorded interrupted (with its PID), current tick cleared, tick finish flushed');
  check('S3A.11', !existsSync(join(f.out, 'beta.count')) && st.projects[roots.beta] === undefined, 'beta never attempted', 'no later project starts after cancellation');
  check('S3A.12', /The active tick was stopped\. Its pass for alpha was cancelled and recorded as interrupted\./.test(r.out) && /Ticket runs already launched keep going/.test(r.out),
    'off says the tick was stopped and alpha cancelled', 'interruption is reported honestly', r.out);
  check('S3A.13', /cancelling process group/.test(t.log()) && /tick interrupted/.test(t.log()), 'tick log records cancellation and interruption', 'the tick reports the interruption in its own (journal) output', t.log());
  check('S3A.14', !existsSync(f.p.lock), 'tick lock gone', 'cancellation was acknowledged and the lock released');
  await sleep(1500);
  check('S3A.15', !existsSync(join(f.out, 'beta.count')) && f.calls().slice(mark).filter((c: any) => c.argv[1] !== 'show').length === 2, 'still no beta run and no further mutating call 1.5 s later', 'no subsequent work after acknowledged cancellation');
  const t2 = f.startTick();
  const e2 = await t2.exit;
  check('S3A.16', e2.code === 0 && /scheduler is off/.test(t2.log()) && !existsSync(join(f.out, 'beta.count')), 'a tick after off does nothing', 'the timer stop leaves no tick that does work');
  check('S3A.17', f.rejected().length === 0, 'stub rejected nothing', 'only expected manager calls');
  killAll([pids.ticket]); by.kill();
}

section('B: SIGTERM to the tick alone (stand-in for systemctl stop under KillMode=process)');
{
  const { f, roots } = setup('s3b-sigterm', [{ name: 'alpha', script: hold() }, { name: 'beta', script: rec('beta') }]);
  const by = bystanders(f);
  const { t, pids, record } = await startHeld(f, 'S3B');
  process.kill(t.pid, 'SIGTERM');
  const e = await timeout(t.exit, 10_000);
  check('S3B.1', e !== 'timeout' && (e as any).code === 143, `tick exit ${JSON.stringify(e)}`, "Factory's tick handles SIGTERM by cancelling and exiting 143");
  check('S3B.2', !alive(pids.pass) && !alive(pids.nested) && !alive(pids.analysis) && !alive(pids.analysisChild) && alive(pids.ticket) && readFileSync(join(f.p.state, 'synthetic-alpha-1.json'), 'utf8') === record,
    'owned tree gone before the tick exited; detached ticket alive with its record', "the tick's own SIGTERM handler cancels exactly its pass group");
  check('S3B.3', alive(by.pids.ownSession) && alive(by.pids.verifierGroup) && alive(by.pids.unrelatedNode), 'bystanders alive', 'confined cancellation');
  const a = readJSON(f.p.stateJson).projects[roots.alpha];
  check('S3B.4', a.result === 'interrupted' && a.reason === 'cancelled' && !existsSync(join(f.out, 'beta.count')) && !existsSync(f.p.lock), `alpha ${JSON.stringify(a)}; beta not run; lock released`, 'interrupted state recorded, no later project');
  f.setUnit('factory-tick.service', { forcedActive: 'active' });
  const r = f.cli(['schedule', 'off']);
  check('S3B.5', r.code === 0 && /The active tick was stopped\./.test(r.out) && !/No tick was running/.test(r.out), 'off after a stop-cancelled tick does not claim no tick ran (manager said active)', 'off reporting uses the manager observation, not just the lock', r.out);
  killAll([pids.ticket]); by.kill();
}

section('C: tick killed outright; orphaned pass group stays owned; off cancels it');
{
  const { f, roots } = setup('s3c-sigkill', [{ name: 'alpha', script: hold() }, { name: 'beta', script: rec('beta') }]);
  const { t, pids } = await startHeld(f, 'S3C');
  process.kill(t.pid, 'SIGKILL');
  await t.exit;
  check('S3C.1', alive(pids.pass) && alive(pids.analysisChild) && readJSON(f.p.lock).pass?.pid === pids.pass, 'after SIGKILL of the tick the pass group is alive and still recorded in the lock', 'ownership survives a crashed tick (no untracked orphan)');
  const t2 = f.startTick();
  const e2 = await t2.exit;
  check('S3C.2', e2.code === 0 && /a dispatcher pass from a dead tick is still running/.test(t2.log()) && !existsSync(join(f.out, 'beta.count')), `new tick: ${t2.log().trim()}`, 'no new pass starts over an orphaned live pass group');
  const r = f.cli(['schedule', 'off']);
  const a = readJSON(f.p.stateJson).projects[roots.alpha];
  check('S3C.3', r.code === 0 && !alive(pids.pass) && !alive(pids.nested) && !alive(pids.analysisChild) && alive(pids.ticket), 'off cancels the orphaned group; detached ticket alive', 'off reaches the recorded group even without its tick');
  check('S3C.4', a.result === 'interrupted' && a.finishedAt === undefined && a.durationMs === undefined && a.exitCode === undefined && !existsSync(f.p.lock),
    `alpha ${JSON.stringify(a)}`, 'interrupted without inventing finish time, duration or exit code; lock reclaimed');
  check('S3C.5', /cancelled and recorded as interrupted/.test(r.out) || /recorded as interrupted/.test(r.out), 'off reports the interrupted pass', 'honest report', r.out);
  killAll([pids.ticket]);
}
finish('s3-cancel');
