// Common setup: install through the real CLI, register and opt in the given projects in order, then global on.
import { join } from 'node:path';
import { existsSync, readFileSync } from 'node:fs';
import { check, fixture, holder, holderPids, procStat, project, readJSON, recorder, waitFor } from './lib.mts';
import type { Fixture } from './lib.mts';

export function setup(name: string, specs: { name: string; script: (f: Fixture) => string; optIn?: boolean }[]) {
  const f = fixture(name);
  const roots: Record<string, string> = {};
  for (const s of specs) roots[s.name] = project(f, s.name, { script: s.script(f) });
  const must = (r: { code: number | null; all: string }, what: string) => { if (r.code !== 0) throw new Error(`${what} failed: ${r.all}`); };
  must(f.cli(['install']), 'install');
  for (const s of specs) must(f.cli(['project', 'add', roots[s.name]]), 'project add');
  for (const s of specs) if (s.optIn !== false) must(f.cli(['schedule', 'on', '--project', s.name]), 'opt-in');
  must(f.cli(['schedule', 'on']), 'schedule on');
  return { f, roots };
}
export const hold = (o: { ignoreTerm?: boolean; seconds?: number } = {}) => (f: Fixture) => holder(f, 'alpha', o);
export const rec = (n: string, code = 0) => (f: Fixture) => recorder(f, n, code);

/** Start a unit-shaped tick and wait for alpha's held pass to have every process in place. */
export async function startHeld(f: Fixture, id: string) {
  const t = f.startTick();
  const ready = await waitFor(() => existsSync(join(f.out, 'alpha.ready')) && existsSync(join(f.out, 'alpha.ticket')), 20_000);
  if (!ready) throw new Error(`alpha never became ready; tick log:\n${t.log()}`);
  const pids = holderPids(f, 'alpha');
  const g = (pid: number) => procStat(pid);
  check(`${id}.own-group`, g(pids.pass).pgrp === pids.pass && g(pids.nested).pgrp === pids.pass && g(pids.analysis).pgrp === pids.pass && g(pids.analysisChild).pgrp === pids.pass,
    `pass ${pids.pass} leads group ${g(pids.pass).pgrp}; nested shell, analysis and analysis child are in it`, 'ownership is established at spawn: every non-detached pass child is in the owned group');
  check(`${id}.ticket-detached`, g(pids.ticket).pgrp !== pids.pass && g(pids.ticket).sid === pids.ticket,
    `detached ticket ${pids.ticket} has its own session/group ${g(pids.ticket).pgrp}`, 'the detached ticket run is outside the owned group (synthetic stand-in for dispatch.mts detaching)');
  return { t, pids, record: readFileSync(join(f.p.state, 'synthetic-alpha-1.json'), 'utf8') };
}
export { readJSON };
