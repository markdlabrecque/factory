#!/bin/sh
# Reproduces the #33 final verification. Usage: run-all.sh [repo]   (default /home/agent/workspace)
# Writes everything to /recovery/evidence/final-verification/out/. Needs Node 22.18+, git, coreutils, /proc (Linux).
# No real systemctl is used: each probe puts ./stub/systemctl first on PATH and the probes PATH contains no other
# directory with a service manager.
set -u
REPO=${1:-/home/agent/workspace}
E=/recovery/evidence/final-verification
S=$E/scripts
O=$E/out
mkdir -p "$O"
cd "$REPO" || exit 2
{ date -u +%FT%TZ; git rev-parse HEAD; git status --porcelain=v1 -b; echo "porcelain-lines: $(git status --porcelain | wc -l)"; } > "$O/git-before-run-all.txt"
node --version > "$O/node-version.txt"
command -v systemctl > "$O/host-systemctl.txt" 2>&1 || echo "no systemctl on host PATH" >> "$O/host-systemctl.txt"
node --test orchestrator/*.test.mts board/*.test.mts cli/test/*.test.mts > "$O/full-suite.tap" 2>&1; echo "exit=$?" > "$O/full-suite.exit"
for i in 1 2; do
  node --test cli/test/schedule-linux.test.mts cli/test/scheduler.test.mts cli/test/schedule.test.mts > "$O/focused-$i.tap" 2>&1; echo "exit=$?" > "$O/focused-$i.exit"
done
for s in s1-lifecycle s3-cancel s4-held-lifecycle s5-failures s6-contracts s7-missing-manager; do
  (cd "$S" && FV_REPO="$REPO" timeout 600 node "$s.mts") > "$O/$s.txt" 2>&1; echo "exit=$?" > "$O/$s.exit"
done
# Leftover probe processes (any sleep/node started under the evidence tree or by synthetic dispatchers).
ps -eo pid,pgid,sid,stat,etimes,args | grep -E 'sleep 300|setInterval|factory.mts tick' | grep -v grep > "$O/leftover-processes.txt" || true
{ date -u +%FT%TZ; git rev-parse HEAD; git status --porcelain=v1 -b; echo "porcelain-lines: $(git status --porcelain | wc -l)"; } > "$O/git-after-run-all.txt"
grep -h '^SUMMARY' "$O"/s*.txt > "$O/probe-summaries.txt"
cat "$O"/*.exit
