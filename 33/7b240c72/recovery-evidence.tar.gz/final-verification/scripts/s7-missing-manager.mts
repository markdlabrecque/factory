// S7: the service manager command is missing altogether (no systemctl on PATH at all). Everything must report unknown or
// fail; nothing may claim on/off success or delete runtime files.
import { existsSync, renameSync } from 'node:fs';
import { join } from 'node:path';
import { check, finish, section } from './lib.mts';
import { rec, setup } from './setup.mts';

section('M: systemctl missing');
const { f, roots } = setup('s7-missing', [{ name: 'alpha', script: rec('alpha') }]);
renameSync(join(f.stubBin, 'systemctl'), join(f.stubBin, 'systemctl.hidden'));
const st = JSON.parse(f.cli(['schedule', 'status', '--json']).out).scheduler;
check('M.1', st.service === 'unknown' && st.phase === 'unknown', `status ${JSON.stringify({ service: st.service, phase: st.phase, reason: st.reason })}`, 'a missing manager is unknown, never on');
const t = f.startTick(); const e = await t.exit;
check('M.2', e.code === 1 && !existsSync(join(f.out, 'alpha.count')), `tick exit ${e.code}: ${t.log().trim()}`, 'tick fails closed without a manager');
let r = f.cli(['schedule', 'off']);
check('M.3', r.code !== 0 && !/Scheduler off/.test(r.out), `off exit ${r.code}`, 'off does not claim success when the manager cannot be reached', r.all);
r = f.cli(['uninstall']);
check('M.4', r.code !== 0 && existsSync(f.p.tickService) && existsSync(f.p.tickTimer) && existsSync(f.p.manifest) && existsSync(f.p.app), `uninstall exit ${r.code}; units, ledger and app kept`, 'uninstall keeps runtime files when scheduling cannot be stopped', r.all);
renameSync(join(f.stubBin, 'systemctl.hidden'), join(f.stubBin, 'systemctl'));
r = f.cli(['uninstall']);
check('M.5', r.code === 0 && !existsSync(f.p.manifest), 'uninstall succeeds once the manager is back', 'retry works');
finish('s7-missing-manager');
