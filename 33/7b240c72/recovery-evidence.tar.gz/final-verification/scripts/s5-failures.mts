// S5: failure handling through the real CLI and production adapter (stub-injected), plus one in-process probe where the
// signal sender is replaced so cancellation cannot be confirmed.
import { existsSync, readFileSync, rmSync, symlinkSync } from 'node:fs';
import { join } from 'node:path';
import { alive, check, finish, killAll, readJSON, section, sleep, waitFor, fixture, project, REPO } from './lib.mts';
import { hold, rec, setup, startHeld } from './setup.mts';

const ledgerUnits = (f: any) => existsSync(f.p.manifest) ? readJSON(f.p.manifest).entries.filter((e: any) => e.kind === 'systemd').map((e: any) => e.unit) : [];

section('F1: failed enable --now');
{
  const f = fixture('s5-f1-enable');
  f.cli(['install']);
  f.fail('once:--user enable --now factory-tick.timer');
  const mark = f.calls().length;
  let r = f.cli(['schedule', 'on']);
  check('F1.1', r.code !== 0 && /Scheduler state now: timer disabled\/inactive, tick service inactive/.test(r.all) && /ledger is kept/.test(r.all),
    `on exit ${r.code}; message reports observed state`, 'a failed enable is reported with the actual manager state, not hidden', r.all);
  check('F1.2', JSON.stringify(ledgerUnits(f)) === JSON.stringify(['factory-board.service', 'factory-tick.service', 'factory-tick.timer']) && existsSync(f.p.tickService) && existsSync(f.p.tickTimer),
    `ledger after failure ${JSON.stringify(ledgerUnits(f))}`, 'the ledger keeps both written units for retry/uninstall');
  check('F1.3', !('enabled' in readJSON(f.p.scheduleConfig)) && JSON.parse(f.cli(['schedule', 'status', '--json']).out).scheduler.phase === 'off',
    'no local enabled flag; status says off', 'no local boolean to roll back: the manager is the source of truth');
  r = f.cli(['schedule', 'on']);
  check('F1.4', r.code === 0 && JSON.stringify(ledgerUnits(f)) === JSON.stringify(['factory-board.service', 'factory-tick.service', 'factory-tick.timer']) && f.unit('factory-tick.timer').enabled && f.unit('factory-tick.timer').active,
    'retry succeeds, no duplicate ledger entries, timer enabled+active', 'repeating on retries safely');
  check('F1.5', JSON.stringify(f.mutating(mark)) === JSON.stringify(['daemon-reload', 'enable --now factory-tick.timer', 'daemon-reload', 'enable --now factory-tick.timer']), `calls ${JSON.stringify(f.mutating(mark))}`, 'exact command construction on failure and retry');
}

section('F2: failed daemon-reload during on, then uninstall');
{
  const f = fixture('s5-f2-reload');
  f.cli(['install']);
  f.fail('once:--user daemon-reload');
  const mark = f.calls().length;
  let r = f.cli(['schedule', 'on']);
  check('F2.1', r.code !== 0 && !f.mutating(mark).includes('enable --now factory-tick.timer') && !f.unit('factory-tick.timer').enabled, `on exit ${r.code}; no enable attempted`, 'nothing is enabled after a failed reload');
  check('F2.2', JSON.stringify(ledgerUnits(f)) === JSON.stringify(['factory-board.service', 'factory-tick.service', 'factory-tick.timer']), 'both units ledgered', 'partial installation stays removable by ledger');
  r = f.cli(['uninstall']);
  check('F2.3', r.code === 0 && !existsSync(f.p.tickService) && !existsSync(f.p.tickTimer) && !existsSync(f.p.manifest), 'uninstall removes both by exact identity', 'partial state is removable');
}

section('F3: second artifact cannot be written (partial install)');
{
  const f = fixture('s5-f3-partial');
  f.cli(['install']);
  // A dangling symlink at the timer path: existsSync() is false (not "unowned"), but writing through it fails ENOENT.
  symlinkSync(join(f.dir, 'no/such/dir/target'), f.p.tickTimer);
  const mark = f.calls().length;
  let r = f.cli(['schedule', 'on']);
  check('F3.1', r.code !== 0 && JSON.stringify(ledgerUnits(f)) === JSON.stringify(['factory-board.service', 'factory-tick.service']) && f.mutating(mark).length === 0,
    `on exit ${r.code}; ledger ${JSON.stringify(ledgerUnits(f))}; mutating calls ${JSON.stringify(f.mutating(mark))}`, 'the service written before the failure stays ledgered; nothing is reloaded or enabled', r.all);
  rmSync(f.p.tickTimer);
  r = f.cli(['schedule', 'on']);
  check('F3.2', r.code === 0 && JSON.stringify(ledgerUnits(f)) === JSON.stringify(['factory-board.service', 'factory-tick.service', 'factory-tick.timer']), 'retry succeeds without duplicate service entry', 'partial install can be repaired by repeating on');
  r = f.cli(['uninstall']);
  check('F3.3', r.code === 0 && !existsSync(f.p.tickService) && !existsSync(f.p.tickTimer), 'uninstall cleans up', 'ledger-driven cleanup');
}

section('F4: unowned unit paths are refused');
{
  const f = fixture('s5-f4-unowned');
  f.cli(['install']);
  const { mkdirSync, writeFileSync } = await import('node:fs');
  writeFileSync(f.p.tickTimer, '# someone else\n');
  const mark = f.calls().length;
  const r = f.cli(['schedule', 'on']);
  check('F4.1', r.code !== 0 && /Refusing to overwrite unowned path/.test(r.all) && readFileSync(f.p.tickTimer, 'utf8') === '# someone else\n' && !existsSync(f.p.tickService) && f.calls().length === mark && !existsSync(f.p.scheduleConfig),
    'on refuses, makes no call, writes nothing', 'Factory never overwrites unowned scheduler paths');
}

section('F5: disable --now fails during off / uninstall / reinstall while a pass is held');
{
  const { f, roots } = setup('s5-f5-disable', [{ name: 'alpha', script: hold() }, { name: 'beta', script: rec('beta') }]);
  const { t, pids } = await startHeld(f, 'F5');
  f.fail('--user disable --now factory-tick.timer');
  const appHash = f.treeHash(f.p.app, []);
  let mark = f.calls().length;
  let r = f.cli(['schedule', 'off']);
  check('F5.1', r.code !== 0 && !f.lines(mark).includes('stop factory-tick.service') && alive(t.pid) && alive(pids.pass) && alive(pids.analysisChild) && existsSync(f.p.lock),
    `off exit ${r.code}; no service stop; tick/pass alive; lock kept`, 'a failed timer disable aborts before any stop or signal and reports failure', r.all);
  r = f.cli(['uninstall']);
  check('F5.2', r.code !== 0 && existsSync(f.p.tickService) && existsSync(f.p.tickTimer) && existsSync(f.p.manifest) && f.treeHash(f.p.app, []) === appHash && alive(pids.pass),
    'uninstall fails and removes nothing (units, manifest, app intact), pass not signalled', 'unresolved stop failure never deletes runtime files');
  r = f.cli(['install']);
  check('F5.3', r.code !== 0 && f.treeHash(f.p.app, []) === appHash && alive(pids.pass), 'reinstall fails before replacing the app', 'reinstall stops at an unresolved stop failure');
  f.clearFail();
  r = f.cli(['schedule', 'off']);
  check('F5.4', r.code === 0 && !alive(pids.pass) && !alive(pids.analysisChild) && alive(pids.ticket) && readJSON(f.p.stateJson).projects[roots.alpha].result === 'interrupted', 'retry off succeeds and cancels', 'the retained runtime lets a retry finish the job');
  await t.exit; killAll([pids.ticket]);
}

section('F6: stop factory-tick.service fails');
{
  const { f, roots } = setup('s5-f6-stop', [{ name: 'alpha', script: hold() }, { name: 'beta', script: rec('beta') }]);
  const { t, pids } = await startHeld(f, 'F6');
  f.fail('--user stop factory-tick.service');
  let r = f.cli(['schedule', 'off']);
  check('F6.1', r.code !== 0 && !f.unit('factory-tick.timer').enabled && alive(t.pid) && alive(pids.pass) && existsSync(f.p.lock),
    `off exit ${r.code}; timer already disabled; tick/pass not signalled`, 'off reports the stop failure instead of pretending completion', r.all);
  r = f.cli(['uninstall']);
  check('F6.2', r.code !== 0 && existsSync(f.p.tickService) && existsSync(f.p.tickTimer) && existsSync(f.p.manifest) && existsSync(f.p.app), 'uninstall fails and keeps units, ledger and app', 'runtime preserved on unresolved stop failure');
  f.clearFail();
  r = f.cli(['uninstall']);
  check('F6.3', r.code === 0 && !alive(pids.pass) && alive(pids.ticket) && !existsSync(f.p.tickService) && !existsSync(f.p.app), 'retry uninstall cancels then removes', 'retry works');
  const e = await t.exit;
  check('F6.4', !existsSync(join(f.out, 'beta.count')) && e.code === 143, `beta never ran; tick exit ${e.code}`, 'no later project during the failed-stop window either (the timer was already disabled; the tick gate stops further work)');
  killAll([pids.ticket]);
}

section('F7: cancellation cannot be confirmed (in-process uninstall/off with a signal sender that does nothing)');
{
  const { f, roots } = setup('s5-f7-unconfirmed', [{ name: 'alpha', script: hold() }]);
  const { t, pids } = await startHeld(f, 'F7');
  const saved = { PATH: process.env.PATH, FACTORY_HOME: process.env.FACTORY_HOME };
  process.env.PATH = f.baseEnv.PATH; process.env.FACTORY_HOME = f.home;
  const { paths } = await import(join(REPO, 'cli/src/paths.mts'));
  const { uninstall } = await import(join(REPO, 'cli/src/commands/uninstall.mts'));
  const { schedule } = await import(join(REPO, 'cli/src/commands/schedule.mts'));
  const { scheduleBackend } = await import(join(REPO, 'cli/src/platform/scheduler.mts'));
  const { Systemd } = await import(join(REPO, 'cli/src/platform/systemd.mts'));
  const p = paths(f.home);
  const sent: string[] = [];
  const cancel = { kill: (pid: number, sig: string) => { sent.push(`${pid}:${sig}`); }, graceMs: 300, confirmMs: 300, pollMs: 20 };
  const logs: string[] = []; const ol = console.log; console.log = (...a: unknown[]) => { logs.push(a.join(' ')); };
  let err1 = '', err2 = '';
  try { await schedule(p, scheduleBackend(p), 'off', { cancel }); } catch (e) { err1 = (e as Error).message; }
  try { await uninstall(p, new Systemd(p), { cancel }); } catch (e) { err2 = (e as Error).message; }
  console.log = ol;
  process.env.PATH = saved.PATH; if (saved.FACTORY_HOME === undefined) delete process.env.FACTORY_HOME; else process.env.FACTORY_HOME = saved.FACTORY_HOME;
  check('F7.1', /did not exit after SIGKILL/.test(err1) && /did not exit after SIGKILL/.test(err2), `off error: ${err1.split('\n')[0]}; uninstall error: ${err2.split('\n')[0]}`, 'unconfirmed cancellation is a failure, never a success');
  check('F7.2', sent.length > 0 && sent.every(s => s.startsWith(`${t.pid}:`)), `signals requested: ${JSON.stringify(sent)}`, 'only the recorded tick pid was targeted');
  check('F7.3', existsSync(f.p.lock) && existsSync(f.p.manifest) && existsSync(f.p.tickService) && existsSync(f.p.tickTimer) && existsSync(f.p.app) && readJSON(f.p.stateJson).projects[(Object.keys(readJSON(f.p.stateJson).projects)[0])].result === 'running',
    'lock, manifest, units, app and running state all kept', 'runtime files are kept when cancellation is unconfirmed, so a retry knows what to cancel');
  check('F7.4', !logs.some(l => /Removing systemd/.test(l)), 'no removal was attempted', 'no false success');
  const r = f.cli(['uninstall']);
  check('F7.5', r.code === 0 && !alive(pids.pass) && alive(pids.ticket) && !existsSync(f.p.manifest), 'a real retry cancels and uninstalls', 'retry after unconfirmed cancellation');
  await t.exit; killAll([pids.ticket]);
}

section('F8: manager query errors are unknown and fail closed');
{
  const { f, roots } = setup('s5-f8-unknown', [{ name: 'alpha', script: rec('alpha') }]);
  f.fail('--user show factory-tick.timer --property=LoadState,ActiveState,UnitFileState,LastTriggerUSec');
  let r = f.cli(['schedule', 'status', '--json']);
  const st = JSON.parse(r.out);
  check('F8.1', st.scheduler.service === 'unknown' && st.scheduler.phase === 'unknown' && st.scheduler.serviceEnabled === null && typeof st.scheduler.reason === 'string', `status ${JSON.stringify(st.scheduler)}`, 'a query failure is reported as unknown, never on or off');
  r = f.cli(['schedule', 'status']);
  check('F8.2', /Scheduler: unknown/.test(r.out) && /ready/.test(r.out) === false, 'text status says unknown and no project is ready', 'unknown blocks scheduled work', r.out);
  const t = f.startTick();
  const e = await t.exit;
  check('F8.3', e.code === 1 && /scheduler state unknown/.test(t.log()) && !existsSync(join(f.out, 'alpha.count')), `tick exit ${e.code}: ${t.log().trim()}`, 'the tick fails closed on unknown: no dispatch, nonzero exit');
  r = f.cli(['doctor']);
  check('F8.4', r.code !== 0 && /FAIL Scheduler: the service manager can't be read/.test(r.out), 'doctor FAILs the scheduler check', 'doctor never reports unknown as healthy', r.out);
  r = f.cli(['schedule', 'on', '--project', 'alpha']);
  check('F8.5', /unknown state/.test(r.out), 'project opt-in mentions the unknown state', 'honest state reporting', r.out);
  f.clearFail();
  f.fail('--user show factory-tick.service --property=LoadState,ActiveState');
  const t2 = f.startTick();
  const e2 = await t2.exit;
  check('F8.6', e2.code === 1 && !existsSync(join(f.out, 'alpha.count')), 'a failed tick-service query also fails closed', 'any status query failure is unknown');
}

section('F9: distinct observations and stopping mid-tick');
{
  const { f, roots } = setup('s5-f9-states', [{ name: 'alpha', script: hold({ seconds: 3 }) }, { name: 'beta', script: rec('beta') }]);
  f.setUnit('factory-tick.timer', { enabled: true, active: false });
  let st = JSON.parse(f.cli(['schedule', 'status', '--json']).out).scheduler;
  let t = f.startTick(); let e = await t.exit;
  check('F9.1', st.serviceEnabled === true && st.timerActive === false && st.phase === 'off' && e.code === 0 && /enabled but not running/.test(t.log()) && !existsSync(join(f.out, 'alpha.pass')),
    `enabled/inactive -> ${JSON.stringify({ serviceEnabled: st.serviceEnabled, timerActive: st.timerActive, phase: st.phase })}; tick: ${t.log().trim()}`, 'enabled/inactive is a distinct observation and does no work');
  const doc1 = f.cli(['doctor']).out;
  f.setUnit('factory-tick.timer', { enabled: false, active: true });
  st = JSON.parse(f.cli(['schedule', 'status', '--json']).out).scheduler;
  const txt = f.cli(['schedule', 'status']).out;
  t = f.startTick(); e = await t.exit;
  check('F9.2', st.serviceEnabled === false && st.timerActive === true && st.phase === 'off' && /running but not enabled/.test(txt) && e.code === 0 && !existsSync(join(f.out, 'alpha.pass')),
    `disabled/active -> ${JSON.stringify({ serviceEnabled: st.serviceEnabled, timerActive: st.timerActive, phase: st.phase })}`, 'disabled/active is distinct from enabled/active; no work');
  const doc2 = f.cli(['doctor']).out;
  check('F9.3', /FAIL Scheduler: the timer is enabled but inactive/.test(doc1) && /WARN Scheduler: the timer is running but not enabled/.test(doc2), 'doctor distinguishes the two', 'doctor reads enablement and activity separately', doc1 + doc2);
  f.setUnit('factory-tick.timer', { enabled: true, active: true });
  t = f.startTick();
  await waitFor(() => existsSync(join(f.out, 'alpha.ready')), 10_000);
  f.setUnit('factory-tick.timer', { enabled: false, active: false }); // timer turned off outside Factory while alpha runs
  e = await t.exit;
  const s = readJSON(f.p.stateJson);
  check('F9.4', s.projects[roots.alpha].result === 'ok' && !existsSync(join(f.out, 'beta.count')) && /no longer on/.test(t.log()),
    `alpha ${s.projects[roots.alpha].result}; beta not run; log: ${t.log().trim().split('\n').slice(-1)}`, 'the tick re-queries the manager before each project and starts no later work once the timer is off');
  killAll([Number(readFileSync(join(f.out, 'alpha.ticket'), 'utf8'))]);
}
finish('s5-failures');
