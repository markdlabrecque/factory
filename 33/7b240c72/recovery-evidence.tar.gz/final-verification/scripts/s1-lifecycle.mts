// S1: the real CLI lifecycle through the production SystemdSchedule adapter and the independent stub:
// install -> project add -> project opt-in -> global on (inside a checkout) -> units -> tick (unit-shaped) -> manual tick
// with a caller override -> status -> off -> tick after off -> uninstall --dry-run -> uninstall -> repeat uninstall.
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { check, finish, fixture, git, note, parseService, parseUnit, project, readJSON, readText, section, NODE } from './lib.mts';

const f = fixture('s1-lifecycle');
const alpha = project(f, 'alpha');
const beta = project(f, 'beta');
const { p } = f;

section('install');
let r = f.cli(['install']);
check('S1.1', r.code === 0, 'factory install exits 0', 'install works against the stub', r.all);
check('S1.2', JSON.stringify(f.mutating()) === JSON.stringify(['daemon-reload', 'enable factory-board.service', 'restart factory-board.service']),
  `fresh install makes only the board calls ${JSON.stringify(f.mutating())}`, 'fresh install never installs, enables or starts the scheduler');
check('S1.3', !existsSync(p.tickService) && !existsSync(p.tickTimer) && !existsSync(p.scheduleConfig), 'no tick unit files and no schedule.json after install', 'install alone never enables scheduling');
r = f.cli(['schedule', 'status', '--json']);
let st = JSON.parse(r.out);
check('S1.4', r.code === 0 && st.scheduler.phase === 'off' && st.scheduler.service === 'missing' && st.scheduler.serviceEnabled === false, `status after install: phase=${st.scheduler.phase} service=${st.scheduler.service}`, 'status reads the manager: a missing timer is off, not on');

section('project registration and opt-in');
for (const root of [alpha, beta]) { r = f.cli(['project', 'add', root]); check('S1.5', r.code === 0, `project add ${root.split('/').pop()}`, 'registration works', r.all); }
let reg = readJSON(p.projects);
check('S1.6', reg.projects.every((x: any) => x.schedule === undefined), 'registered projects carry no schedule member', 'registration never opts a project in');
let mark = f.calls().length;
r = f.cli(['schedule', 'on', '--project', 'alpha']);
reg = readJSON(p.projects);
const a = reg.projects.find((x: any) => x.name === 'alpha');
check('S1.7', r.code === 0 && a.schedule?.enabled === true && a.schedule?.branch === 'main', `schedule on --project alpha saves ${JSON.stringify(a.schedule)}`, 'project opt-in saves the current named branch in the registry', r.all);
check('S1.8', f.mutating(mark).length === 0 && !existsSync(p.tickTimer), `project opt-in made no mutating systemctl call (${JSON.stringify(f.lines(mark))})`, 'project enable does not start units');
check('S1.9', /scheduler is off/i.test(r.out), 'opt-in tells the user the global scheduler is off', 'opt-in reports the manager state honestly', r.out);

section('global on, run inside the beta checkout');
mark = f.calls().length;
r = f.cli(['schedule', 'on'], { cwd: beta });
check('S1.10', r.code === 0, 'schedule on (no --project) inside a checkout exits 0', 'global on works', r.all);
check('S1.11', JSON.stringify(f.mutating(mark)) === JSON.stringify(['daemon-reload', 'enable --now factory-tick.timer']),
  `global on mutating calls ${JSON.stringify(f.mutating(mark))}`, 'on = write units, daemon-reload, then enable --now of the timer only; the service is never enabled');
const reload = f.calls().slice(mark).find((c: any) => c.argv[1] === 'daemon-reload');
check('S1.12', reload?.files['factory-tick.service'] && reload?.files['factory-tick.timer'], 'both unit files were on disk when daemon-reload ran', 'units are written before the manager is asked to load them');
const m = readJSON(p.manifest);
const units = m.entries.filter((e: any) => e.kind === 'systemd').map((e: any) => e.unit);
check('S1.13', JSON.stringify(units) === JSON.stringify(['factory-board.service', 'factory-tick.service', 'factory-tick.timer']), `ledger systemd entries in order ${JSON.stringify(units)}`, 'service is ledgered before the timer, each exactly once, at exact paths');
check('S1.14', m.entries.find((e: any) => e.unit === 'factory-tick.service')?.path === p.tickService && m.entries.find((e: any) => e.unit === 'factory-tick.timer')?.path === p.tickTimer, 'ledgered paths are the exact unit paths', 'exact ledger identities');
reg = readJSON(p.projects);
check('S1.15', reg.projects.find((x: any) => x.name === 'beta').schedule === undefined, 'beta is still not opted in after global on inside its checkout', 'no --project targets the global scheduler even in a checkout; global on opts in no project');
const cfg = readJSON(p.scheduleConfig);
check('S1.16', JSON.stringify(Object.keys(cfg).sort()) === JSON.stringify(['node', 'path', 'version']) && cfg.node === NODE && cfg.path === f.baseEnv.PATH && (statSync(p.scheduleConfig).mode & 0o777) === 0o600,
  `schedule.json = ${JSON.stringify(cfg)} mode ${(statSync(p.scheduleConfig).mode & 0o777).toString(8)}`, 'launch config holds only PATH and absolute Node (0600), no enabled/desiredEnabled switch');
check('S1.17', f.unit('factory-tick.timer').enabled && f.unit('factory-tick.timer').active && !f.unit('factory-tick.service').enabled, 'stub: timer enabled+active, service not enabled', 'only the timer is enabled');

section('generated units');
const svc = parseService(readText(p.tickService));
const D = svc.directives;
check('S1.18', JSON.stringify(svc.argv) === JSON.stringify([NODE, join(p.app, 'cli/bin/factory.mts'), 'tick']), `ExecStart argv ${JSON.stringify(svc.argv)}`, 'the service runs the installed app as `node <app>/cli/bin/factory.mts tick` with absolute Node');
check('S1.19', svc.env.PATH === cfg.path && svc.env.SANDCASTLE_STATE_DIR === p.state && svc.env.FACTORY_HOME === f.home && Object.keys(svc.env).length === 3,
  `Environment ${JSON.stringify(svc.env)}`, 'saved PATH, HOME and state are passed by unit Environment=, nothing else');
check('S1.20', D.Type?.[0] === 'oneshot' && D.KillMode?.[0] === 'process' && D.TimeoutStartSec?.[0] === 'infinity' && D.StandardOutput?.[0] === 'journal' && D.StandardError?.[0] === 'journal',
  `Type=${D.Type} KillMode=${D.KillMode} TimeoutStartSec=${D.TimeoutStartSec} StandardOutput=${D.StandardOutput}`, 'oneshot, KillMode=process, no finite start timeout, journal output');
check('S1.21', !D.EnvironmentFile && !D.StandardInput && !D.ExecStartPre && !/\b(bash|sh) -[lc]|\.profile|\.bashrc|source /.test(readText(p.tickService).split('\n').filter(l => !l.startsWith('#')).join('\n')),
  'no EnvironmentFile, no StandardInput override, no shell/profile sourcing', 'no shell environment is sourced; systemd default (null) stdin is used');
check('S1.22', !/\[Install\]/.test(readText(p.tickService)), 'the service has no [Install] section', 'the service cannot be enabled on its own; only the timer is');
note(`TimeoutStopSec=${D.TimeoutStopSec}: a stop-only deadline that bounds systemd's wait for the tick's own cancellation; it is not a start/pass timeout.`);
const tmr = parseUnit(readText(p.tickTimer));
const T = tmr.directives;
check('S1.23', T.OnActiveSec?.[0] === '1min' && T.OnUnitInactiveSec?.[0] === '5min' && T.Persistent?.[0] === 'false' && !T.OnBootSec && !T.RandomizedDelaySec && !T.OnCalendar && !T.AccuracySec && T.WantedBy?.[0] === 'timers.target',
  `timer ${JSON.stringify(T)}`, 'first tick 60 s after activation, then 5 min after each tick finishes; no boot/randomized/calendar/catch-up');

section('tick, run exactly as the unit would run it');
mark = f.calls().length;
let t = f.startTick();
let e = await t.exit;
check('S1.24', e.code === 0, `tick exit ${e.code}`, 'a successful tick exits 0', t.log());
const run1 = Object.fromEntries(readText(join(f.out, 'alpha.run-1.txt')).trim().split('\n').map(l => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1)]));
const args1 = readText(join(f.out, 'alpha.run-1.txt')).split('\n').filter(l => l.startsWith('arg=')).map(l => l.slice(4));
check('S1.25', run1.cwd === alpha && JSON.stringify(args1) === JSON.stringify(['--max', '3']) && run1.PATH === cfg.path && run1.SANDCASTLE_STATE_DIR === p.state && run1.FACTORY_SCHEDULED === '1',
  `dispatcher saw cwd=${run1.cwd} args=${JSON.stringify(args1)} PATH=saved:${run1.PATH === cfg.path} STATE=${run1.SANDCASTLE_STATE_DIR} FACTORY_SCHEDULED=${run1.FACTORY_SCHEDULED}`, 'scheduled pass: cwd=root, --max 3, FACTORY_SCHEDULED=1, saved PATH, p.state');
check('S1.26', run1.stdin_tty === 'no', `dispatcher stdin_tty=${run1.stdin_tty}`, 'under the unit (no stdin) the pass never sees a terminal (trusted systemd default stdin; manual-tick stdin is deferred)');
check('S1.27', run1.pgid === run1.pid && run1.sid === run1.pid, `pass pid=${run1.pid} pgid=${run1.pgid} sid=${run1.sid}`, 'the pass leads its own process group/session, established at spawn');
check('S1.28', !existsSync(join(f.out, 'beta.count')), 'beta (not opted in) was not dispatched', 'only opted-in projects run');
let s = readJSON(p.stateJson);
const sa = s.projects[alpha];
check('S1.29', sa?.result === 'ok' && sa.exitCode === 0 && sa.pid === Number(run1.pid) && typeof sa.finishedAt === 'string' && sa.durationMs >= 0 && typeof sa.attemptedAt === 'string',
  `state.json alpha ${JSON.stringify(sa)}`, 'the pass PID, result, exit code, UTC finish and duration are persisted');
check('S1.30', s.startedAt && s.finishedAt && s.durationMs >= 0 && s.pid === undefined && s.currentRoot === undefined && s.projects[beta]?.result === 'skipped' && /not opted in/.test(s.projects[beta]?.reason),
  `state.json tick ${JSON.stringify({ startedAt: s.startedAt, finishedAt: s.finishedAt, durationMs: s.durationMs, pid: s.pid, beta: s.projects[beta] })}`, 'last tick start/finish/duration persisted; skips are per-project state with a reason');
check('S1.31', !existsSync(p.lock), 'tick lock released after the tick', 'the tick lock is not leaked');
check('S1.32', f.mutating(mark).length === 0, `the tick made only read calls ${JSON.stringify(f.lines(mark))}`, 'the tick never changes the timer');

section('manual tick with a caller override of SANDCASTLE_STATE_DIR');
mkdirSync(join(f.dir, 'elsewhere'), { recursive: true });
r = f.cli(['tick'], { cwd: join(f.dir, 'elsewhere'), env: { SANDCASTLE_STATE_DIR: join(f.dir, 'elsewhere') } });
const run2 = readText(join(f.out, 'alpha.run-2.txt'));
check('S1.33', r.code === 0 && run2.includes(`SANDCASTLE_STATE_DIR=${p.state}\n`) && run2.includes(`cwd=${alpha}\n`), 'a manual tick with a caller override still gives the pass p.state and cwd=root', 'scheduled children always get SANDCASTLE_STATE_DIR=p.state', run2);

section('status');
r = f.cli(['schedule', 'status', '--json']);
st = JSON.parse(r.out);
check('S1.34', st.scheduler.phase === 'waiting' && st.scheduler.serviceEnabled === true && st.scheduler.timerActive === true && st.scheduler.tickActive === false && st.scheduler.cap === 3 && st.scheduler.intervalMs === 300000,
  `status --json scheduler ${JSON.stringify(st.scheduler)}`, 'status reports timer enablement, timer activity and tick activity separately from the manager');
check('S1.35', st.projects.find((x: any) => x.name === 'alpha')?.last?.result === 'ok' && st.projects.find((x: any) => x.name === 'beta')?.schedule === null, 'status lists the last alpha result and beta not opted in', 'initial status shows saved settings and last project result');
r = f.cli(['schedule', 'status', '--json', '--project', 'alpha']);
st = JSON.parse(r.out);
check('S1.36', st.projects.length === 1 && st.projects[0].name === 'alpha', 'status --project alpha filters to alpha', '--project <name> contract on status');
r = f.cli(['schedule', 'status', '--project', beta]);
check('S1.37', r.code === 0 && /^beta /m.test(r.out) && !/^alpha /m.test(r.out) && /Scheduler: on/.test(r.out), 'status --project <path> (text) filters to beta and says on', '--project <path> contract; text status', r.out);

section('off');
mark = f.calls().length;
r = f.cli(['schedule', 'off']);
const offLines = f.lines(mark);
const iDisable = offLines.indexOf('disable --now factory-tick.timer'), iStop = offLines.indexOf('stop factory-tick.service');
check('S1.38', r.code === 0 && iDisable >= 0 && iStop > iDisable && JSON.stringify(f.mutating(mark)) === JSON.stringify(['disable --now factory-tick.timer', 'stop factory-tick.service']),
  `off calls ${JSON.stringify(offLines)}`, 'off = systemctl --user disable --now factory-tick.timer, THEN stop factory-tick.service; nothing else mutates');
check('S1.39', /No tick was running/.test(r.out), 'off with no tick says no tick was running', 'honest report when nothing ran', r.out);
check('S1.40', !f.unit('factory-tick.timer').enabled && !f.unit('factory-tick.timer').active, 'stub timer disabled and inactive after off', 'off disables AND stops the timer');
check('S1.41', JSON.stringify(readJSON(p.scheduleConfig)) === JSON.stringify(cfg) && readJSON(p.projects).projects.find((x: any) => x.name === 'alpha').schedule.enabled === true,
  'schedule.json unchanged and alpha opt-in retained after off', 'off writes no local global boolean and keeps project opt-in');
t = f.startTick();
e = await t.exit;
check('S1.42', e.code === 0 && /scheduler is off/.test(t.log()) && !existsSync(join(f.out, 'alpha.run-3.txt')), `tick after off: exit ${e.code}, log: ${t.log().trim()}`, 'a tick that starts after off (timer race) does no work');
st = JSON.parse(f.cli(['schedule', 'status', '--json']).out);
check('S1.43', st.scheduler.phase === 'off' && st.scheduler.serviceEnabled === false, `phase after off ${st.scheduler.phase}`, 'status follows the manager');

section('uninstall');
writeFileSync(join(p.unitDir, 'unrelated.service'), '[Service]\nExecStart=/bin/true\n');
writeFileSync(join(p.unitDir, 'factory-other.timer'), '# unowned lookalike\n');
const projHash = [f.treeHash(alpha, [join(alpha, '.git')]), f.treeHash(beta, [join(beta, '.git')]), git(alpha, 'rev-parse', 'HEAD'), git(beta, 'rev-parse', 'HEAD'), git(alpha, 'status', '--porcelain'), git(alpha, 'stash', 'list')].join('|');
const before = f.treeHash();
mark = f.calls().length;
r = f.cli(['uninstall', '--dry-run']);
check('S1.44', r.code === 0 && f.calls().length === mark && f.treeHash() === before, `dry-run: ${f.calls().length - mark} systemctl calls, tree unchanged=${f.treeHash() === before}`, 'uninstall --dry-run makes no manager call and changes no file', r.all);
mark = f.calls().length;
r = f.cli(['uninstall']);
const un = f.lines(mark);
check('S1.45', r.code === 0, 'uninstall exits 0', 'uninstall works', r.all);
const firstRemove = un.findIndex(l => l === 'stop factory-tick.timer');
check('S1.46', un.indexOf('disable --now factory-tick.timer') >= 0 && un.indexOf('disable --now factory-tick.timer') < un.indexOf('stop factory-tick.service') && un.indexOf('stop factory-tick.service') < firstRemove,
  `uninstall calls ${JSON.stringify(un)}`, 'uninstall stops scheduling (disable --now timer, stop service) before removing any unit');
const removeCall = f.calls().slice(mark).find((c: any) => c.argv.slice(1).join(' ') === 'stop factory-tick.timer');
check('S1.47', removeCall?.files['factory-tick.timer'] === true, 'unit files still existed at the first removal step', 'nothing was deleted before scheduling was stopped');
check('S1.48', !existsSync(p.tickService) && !existsSync(p.tickTimer) && !existsSync(p.board) && !existsSync(p.manifest) && !existsSync(p.app), 'tick units, board unit, app and manifest removed', 'exact ledgered entries are removed');
check('S1.49', existsSync(join(p.unitDir, 'unrelated.service')) && existsSync(join(p.unitDir, 'factory-other.timer')) && existsSync(p.scheduleConfig) && existsSync(p.projects) && existsSync(p.stateJson),
  'unrelated.service, unowned factory-other.timer, schedule.json, projects.json, state.json kept', 'uninstall preserves unrelated services, unowned lookalikes, config and history');
const projAfter = [f.treeHash(alpha, [join(alpha, '.git')]), f.treeHash(beta, [join(beta, '.git')]), git(alpha, 'rev-parse', 'HEAD'), git(beta, 'rev-parse', 'HEAD'), git(alpha, 'status', '--porcelain'), git(alpha, 'stash', 'list')].join('|');
check('S1.50', projAfter === projHash, 'project files, HEADs, status and stash unchanged across the whole lifecycle', 'Factory never modifies project checkouts');
r = f.cli(['uninstall']);
check('S1.51', r.code === 0 && /Nothing installed/.test(r.out) && /Untracked service, left untouched: .*factory-other.timer/.test(r.out), 'repeat uninstall is a no-op and leaves the lookalike', 'repeat removal is safe');
check('S1.52', f.rejected().length === 0, `stub rejected ${f.rejected().length} calls`, 'Factory made no unexpected systemctl call shape');
writeFileSync(join(f.out, 'calls.json'), JSON.stringify(f.calls(), null, 1));
finish('s1-lifecycle');
