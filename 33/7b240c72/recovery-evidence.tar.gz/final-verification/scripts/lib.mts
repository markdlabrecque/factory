// Shared harness for the #33 final-verification probes. Every fixture lives under
// /recovery/evidence/final-verification/work/<scenario>/ and uses a disposable FACTORY_HOME, synthetic Git projects with
// a bare local origin, test-owned dispatcher scripts and the independent stub in ./stub/systemctl placed FIRST on PATH.
// Nothing here can reach a real service manager (this host has no systemctl at all; the stub rejects unknown shapes).
// Each check prints `PASS|FAIL <id>: <assertion>. Proves: <Factory-owned behaviour>` so the output explains itself.
import { execFileSync, spawn, spawnSync } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { chmodSync, copyFileSync, existsSync, mkdirSync, openSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export const EVID = '/recovery/evidence/final-verification';
export const REPO = process.env.FV_REPO ?? '/home/agent/workspace';
export const FACTORY = join(REPO, 'cli/bin/factory.mts');
export const NODE = process.execPath;
const HERE = dirname(fileURLToPath(import.meta.url));

let fails = 0, passes = 0;
export function check(id: string, ok: boolean, assertion: string, proves: string, detail?: unknown) {
  if (ok) passes++; else fails++;
  console.log(`${ok ? 'PASS' : 'FAIL'} ${id}: ${assertion}. Proves: ${proves}${!ok && detail !== undefined ? `\n      detail: ${typeof detail === 'string' ? detail : JSON.stringify(detail)}` : ''}`);
}
export function note(s: string) { console.log(`  note: ${s}`); }
export function section(s: string) { console.log(`\n## ${s}`); }
export function finish(name: string) {
  console.log(`\nSUMMARY ${name}: ${passes} pass, ${fails} fail`);
  process.exitCode = fails ? 1 : 0;
}
export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
export async function waitFor(fn: () => boolean, ms: number, step = 50): Promise<boolean> {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (fn()) return true; await sleep(step); }
  return fn();
}
export function alive(pid: number): boolean {
  try { const s = readFileSync(`/proc/${pid}/stat`, 'utf8'); return s.slice(s.lastIndexOf(')') + 2)[0] !== 'Z'; } catch { return false; }
}
export function procStat(pid: number) {
  const s = readFileSync(`/proc/${pid}/stat`, 'utf8');
  const f = s.slice(s.lastIndexOf(')') + 2).split(' ');
  return { state: f[0], ppid: Number(f[1]), pgrp: Number(f[2]), sid: Number(f[3]) };
}
export const readJSON = (f: string) => JSON.parse(readFileSync(f, 'utf8'));
export const readText = (f: string) => readFileSync(f, 'utf8');
export const num = (f: string) => Number(readFileSync(f, 'utf8').trim());

const git = (cwd: string, ...args: string[]) => execFileSync('git', ['-c', 'user.name=fv', '-c', 'user.email=fv@example.invalid', '-c', 'init.defaultBranch=main', ...args], { cwd, stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8' }).trim();
export { git };

export type Fixture = ReturnType<typeof fixture>;
/** A fresh fixture dir. `homeName` lets a scenario put awkward characters in FACTORY_HOME. */
export function fixture(name: string, homeName = 'home') {
  const dir = join(EVID, 'work', name);
  rmSync(dir, { recursive: true, force: true });
  mkdirSync(dir, { recursive: true });
  const home = join(dir, homeName);
  mkdirSync(home, { recursive: true });
  const out = join(dir, 'out'); mkdirSync(out, { recursive: true });
  const stubBin = join(home, 'stubbin');  // inside HOME so a quoted HOME also quotes the saved PATH
  const stubState = join(home, 'state');  // ../state relative to the stub
  mkdirSync(stubBin, { recursive: true }); mkdirSync(stubState, { recursive: true });
  copyFileSync(join(HERE, 'stub/systemctl'), join(stubBin, 'systemctl'));
  chmodSync(join(stubBin, 'systemctl'), 0o755);
  const unitDir = join(home, '.config/systemd/user');
  writeFileSync(join(stubState, 'unitdir'), unitDir + '\n');
  const p = {
    app: join(home, '.local/share/factory/app'), manifest: join(home, '.local/share/factory/manifest.json'),
    config: join(home, '.config/factory'), projects: join(home, '.config/factory/projects.json'), scheduleConfig: join(home, '.config/factory/schedule.json'),
    state: join(home, '.local/state/factory'), schedulerState: join(home, '.local/state/factory/scheduler'),
    stateJson: join(home, '.local/state/factory/scheduler/state.json'), lock: join(home, '.local/state/factory/scheduler/tick.lock'),
    unitDir, tickService: join(unitDir, 'factory-tick.service'), tickTimer: join(unitDir, 'factory-tick.timer'), board: join(unitDir, 'factory-board.service'),
  };
  // Only the stub, node and the coreutils/git the synthetic scripts need. No other dir: a missed call cannot fall through.
  const PATH = `${stubBin}:${dirname(NODE)}:/usr/bin:/bin`;
  const baseEnv = { PATH, FACTORY_HOME: home, HOME: home, LANG: 'C.UTF-8' } as Record<string, string>;
  const calls = () => existsSync(join(stubState, 'calls.jsonl')) ? readText(join(stubState, 'calls.jsonl')).split('\n').filter(Boolean).map(l => JSON.parse(l)) : [];
  const f = {
    name, dir, home, out, p, stubBin, stubState, baseEnv,
    /** Every recorded call (all outcomes). */
    calls,
    lines: (from = 0) => calls().slice(from).map((c: any) => c.argv.slice(1).join(' ')),
    rejected: () => calls().filter((c: any) => c.outcome === 'rejected'),
    mutating: (from = 0) => calls().slice(from).filter((c: any) => c.argv[1] !== 'show').map((c: any) => c.argv.slice(1).join(' ')),
    unit: (n: string) => { const s = existsSync(join(stubState, 'state.json')) ? readJSON(join(stubState, 'state.json')) : { units: {} }; return s.units[n] ?? { enabled: false, active: false }; },
    setUnit: (n: string, patch: Record<string, unknown>) => {
      const file = join(stubState, 'state.json');
      const s = existsSync(file) ? readJSON(file) : { units: {}, reloads: 0 };
      s.units[n] = { enabled: false, active: false, ...s.units[n], ...patch };
      writeFileSync(file, JSON.stringify(s, null, 2));
    },
    fail: (...lines: string[]) => writeFileSync(join(stubState, 'fail'), lines.map(l => l + '\n').join('')),
    clearFail: () => rmSync(join(stubState, 'fail'), { force: true }),
    watch: (pids: Record<string, number>) => writeFileSync(join(stubState, 'watch'), JSON.stringify({ pids })),
    /** Run the real CLI from the repository checkout (as a person would). */
    cli(args: string[], o: { cwd?: string; env?: Record<string, string>; bin?: string } = {}) {
      const r = spawnSync(NODE, [o.bin ?? FACTORY, ...args], { cwd: o.cwd ?? home, env: { ...baseEnv, ...(o.env ?? {}) }, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 180_000 });
      const text = `$ factory ${args.join(' ')}\n${r.stdout}${r.stderr ? `[stderr]\n${r.stderr}` : ''}[exit ${r.status}${r.signal ? ` signal ${r.signal}` : ''}]\n`;
      writeFileSync(join(out, 'transcript.txt'), text + '\n', { flag: 'a' });
      return { code: r.status, out: r.stdout, err: r.stderr, all: r.stdout + r.stderr };
    },
    /** The unit's ExecStart argv and Environment, parsed with systemd's documented quoting rules (unitparse below). */
    unitExec() { return parseService(readText(p.tickService)); },
    /** Start a tick exactly as factory-tick.service would: the unit's argv and Environment only, stdin /dev/null,
     *  cwd = HOME (systemd's default for user units), in its own session (as a service is). */
    startTick(extraEnv: Record<string, string> = {}) {
      const u = parseService(readText(p.tickService));
      const log = join(out, `tick-${Date.now()}.log`);
      const fd = openSync(log, 'a');
      const child = spawn(u.argv[0], u.argv.slice(1), { cwd: home, env: { HOME: home, ...u.env, ...extraEnv }, stdio: ['ignore', fd, fd], detached: true });
      const exit = new Promise<{ code: number | null; signal: string | null }>(r => child.on('exit', (code, signal) => r({ code, signal })));
      return { child, pid: child.pid!, exit, log: () => readText(log) };
    },
    /** sha256 over every file under HOME except the stub's own state, for "nothing changed" assertions. */
    treeHash(root = home, skip = [stubState]) {
      const h = createHash('sha256');
      const walk = (d: string) => {
        for (const n of readdirSync(d).sort()) {
          const full = join(d, n);
          if (skip.some(s => full === s)) continue;
          const st = statSync(full, { throwIfNoEntry: false } as any) as any;
          if (!st) { h.update(`dangling ${full}\n`); continue; }
          if (st.isDirectory()) { h.update(`dir ${full}\n`); walk(full); }
          else h.update(`file ${full} ${st.mode} ${createHash('sha256').update(readFileSync(full)).digest('hex')}\n`);
        }
      };
      walk(root);
      return h.digest('hex');
    },
  };
  return f;
}

/** A synthetic project at <fixture>/projects/<name> (or `root`), with a bare origin and pushed main by default. */
export function project(f: Fixture, name: string, o: { script?: string; origin?: boolean; push?: boolean; exec?: boolean; current?: boolean; root?: string } = {}) {
  const root = o.root ?? join(f.dir, 'projects', name);
  mkdirSync(join(root, '.sandcastle'), { recursive: true });
  git(root, 'init', '-q', '-b', 'main');
  writeFileSync(join(root, 'README'), `${name}\n`);
  writeFileSync(join(root, '.gitignore'), '.sandcastle/\n');
  git(root, 'add', '.'); git(root, 'commit', '-q', '-m', 'init');
  if (o.origin !== false) {
    const origin = join(f.dir, 'origins', `${name}.git`);
    mkdirSync(origin, { recursive: true });
    git(origin, 'init', '-q', '--bare');
    git(root, 'remote', 'add', 'origin', origin);
    if (o.push !== false) git(root, 'push', '-q', 'origin', 'main');
  }
  writeFileSync(join(root, '.sandcastle/dispatch.sh'), o.script ?? recorder(f, name), { mode: o.exec === false ? 0o644 : 0o755 });
  if (o.exec === false) chmodSync(join(root, '.sandcastle/dispatch.sh'), 0o644);
  writeFileSync(join(root, '.sandcastle/config.mts'), `export const TRACKER = {\n  project: "synthetic/${name}",\n};\n`);
  const current = o.current !== false;
  writeFileSync(join(root, '.sandcastle/dispatch.mts'), current ? '// synthetic copy\nreserveRun(iid, pid);\n' : '// synthetic old copy\nspawn();\n');
  writeFileSync(join(root, '.sandcastle/board.mts'), current ? 'export function reserveRun() {}\n' : '// old\n');
  return root;
}
/** A dispatcher that records what it was given and exits with `code`. */
export function recorder(f: Fixture, name: string, code = 0) {
  return `#!/bin/sh
O='${f.out}'
n=$(cat "$O/${name}.count" 2>/dev/null || echo 0); n=$((n+1)); echo $n > "$O/${name}.count"
{
  echo "pid=$$"; echo "cwd=$(pwd)"; echo "argc=$#"; for a in "$@"; do echo "arg=$a"; done
  echo "PATH=$PATH"; echo "SANDCASTLE_STATE_DIR=\${SANDCASTLE_STATE_DIR-<unset>}"; echo "FACTORY_SCHEDULED=\${FACTORY_SCHEDULED-<unset>}"
  if [ -t 0 ]; then echo stdin_tty=yes; else echo stdin_tty=no; fi
  echo "pgid=$(cut -d' ' -f5 /proc/$$/stat)"; echo "sid=$(cut -d' ' -f6 /proc/$$/stat)"
} > "$O/${name}.run-$n.txt"
exit ${code}
`;
}
/** A dispatcher that holds: a nested non-detached shell, a nested "analysis" node process with its own child, and a
 *  detached ticket run (own session, like dispatch.mts launches) that writes a reserveRun-shaped run record. */
export function holder(f: Fixture, name: string, o: { ignoreTerm?: boolean; seconds?: number } = {}) {
  const O = f.out;
  return `#!/bin/sh
O='${O}'
${o.ignoreTerm ? "trap '' TERM\n" : ''}echo $$ > "$O/${name}.pass"
sh -c ${o.ignoreTerm ? `"trap '' TERM; while :; do sleep 1; done"` : "'exec sleep 300'"} &
echo $! > "$O/${name}.nested"
'${NODE}' -e "${o.ignoreTerm ? "process.on('SIGTERM',()=>{});" : ''}const c=require('child_process').spawn('sleep',['300'],{stdio:'ignore'});require('fs').writeFileSync(process.argv[1]+'/${name}.analysis-child',String(c.pid));setInterval(()=>{},1e6)" "$O" &
echo $! > "$O/${name}.analysis"
'${NODE}' -e "const c=require('child_process').spawn('sleep',['300'],{detached:true,stdio:'ignore'});c.unref();const fs=require('fs');fs.writeFileSync(process.argv[1]+'/${name}.ticket',String(c.pid));fs.writeFileSync(process.env.SANDCASTLE_STATE_DIR+'/synthetic-${name}-1.json',JSON.stringify({stage:'setup',note:'starting',starting:true,pid:c.pid}))" "$O"
while [ ! -s "$O/${name}.analysis-child" ]; do sleep 0.05; done
echo ready > "$O/${name}.ready"
${o.seconds ? `sleep ${o.seconds}\necho done > "$O/${name}.done"\nexit 0` : 'wait'}
`;
}
export function holderPids(f: Fixture, name: string) {
  const r = (k: string) => num(join(f.out, `${name}.${k}`));
  return { pass: r('pass'), nested: r('nested'), analysis: r('analysis'), analysisChild: r('analysis-child'), ticket: r('ticket') };
}

/** Parse a unit file per systemd.syntax/systemd.service: words split on whitespace, double quotes group, C escapes
 *  are unescaped, `%%` is a literal `%` (any other specifier is flagged), and in ExecStart `$$` is a literal `$` (a bare
 *  `$NAME` would be variable expansion and is flagged). Environment= does no `$` expansion. */
export function words(value: string): string[] {
  const out: string[] = []; let cur = '', inQ = false, any = false;
  for (let i = 0; i < value.length; i++) {
    const c = value[i];
    if (c === '\\') { const n = value[++i]; cur += ({ n: '\n', t: '\t', '\\': '\\', '"': '"', "'": "'" } as Record<string, string>)[n] ?? (() => { throw new Error(`unexpected escape \\${n}`); })(); any = true; continue; }
    if (c === '"') { inQ = !inQ; any = true; continue; }
    if (!inQ && /\s/.test(c)) { if (any) out.push(cur); cur = ''; any = false; continue; }
    cur += c; any = true;
  }
  if (inQ) throw new Error('unterminated quote');
  if (any) out.push(cur);
  return out;
}
const specifiers = (s: string) => s.replace(/%(.)/g, (_m, c) => { if (c === '%') return '%'; throw new Error(`specifier %${c} would expand`); });
const dollars = (s: string) => s.replace(/\$(\$|\{?[A-Za-z_])/g, (_m, c) => { if (c === '$') return '$'; throw new Error('variable expansion'); });
export function parseService(text: string) {
  const lines = text.split('\n').filter(l => !/^\s*(#|;|$)/.test(l));
  const execs = lines.filter(l => l.startsWith('ExecStart='));
  if (execs.length !== 1) throw new Error(`expected exactly one ExecStart, got ${execs.length}`);
  const argv = words(execs[0].slice('ExecStart='.length)).map(w => dollars(specifiers(w)));
  const env: Record<string, string> = {};
  for (const l of lines.filter(l => l.startsWith('Environment='))) for (const w of words(l.slice('Environment='.length))) {
    const v = specifiers(w); const i = v.indexOf('='); env[v.slice(0, i)] = v.slice(i + 1);
  }
  const directives: Record<string, string[]> = {};
  for (const l of lines) { const m = l.match(/^([A-Za-z]+)=(.*)$/); if (m) (directives[m[1]] ??= []).push(m[2]); }
  return { argv, env, directives, lines };
}
export function parseUnit(text: string) {
  const directives: Record<string, string[]> = {}; const sections: string[] = [];
  for (const l of text.split('\n')) {
    if (/^\s*(#|;|$)/.test(l)) continue;
    const s = l.match(/^\[(.+)\]$/); if (s) { sections.push(s[1]); continue; }
    const m = l.match(/^([A-Za-z]+)=(.*)$/); if (m) (directives[m[1]] ??= []).push(m[2]);
  }
  return { directives, sections };
}
/** Bystanders that must never be signalled: one in its own session, one in the verifier's own process group, one Node. */
export function bystanders(f: Fixture) {
  const own = spawn('sleep', ['300'], { stdio: 'ignore', detached: true });
  const same = spawn('sleep', ['300'], { stdio: 'ignore' });
  const nodeOne = spawn(NODE, ['-e', 'setInterval(()=>{},1e6)'], { stdio: 'ignore', detached: true });
  own.unref(); nodeOne.unref();
  return { pids: { ownSession: own.pid!, verifierGroup: same.pid!, unrelatedNode: nodeOne.pid! }, kill() { for (const c of [own, same, nodeOne]) try { c.kill('SIGKILL'); } catch {} } };
}
export function killAll(pids: number[]) { for (const pid of pids) { try { process.kill(pid, 'SIGKILL'); } catch {} } }
export type { ChildProcess };
