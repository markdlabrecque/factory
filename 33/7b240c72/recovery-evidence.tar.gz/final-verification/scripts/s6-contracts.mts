// S6: quoting through a hostile FACTORY_HOME, opt-in checks, saved-branch guard, failed-pass exit status, CLI argument
// contract, deleted-checkout opt-out, and the one-tick-per-user lock.
import { chmodSync, existsSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { check, finish, fixture, git, NODE, parseService, project, readJSON, readText, recorder, section, waitFor, words } from './lib.mts';
import { hold, rec, setup, startHeld } from './setup.mts';

for (const [qid, weird, runIt] of [['Q', `h o"m%e$X'q $HOME %h`, true], ['QB', `h o"m%e$X\\b'q`, false]] as const) {
  section(`${qid}: quoting with ${runIt ? "space, double quote, percent, dollar, single quote" : "a backslash as well (parse-only: Node refuses ESM entry paths containing a backslash)"} in FACTORY_HOME (so in app, state and PATH)`);
  const f = fixture(`s6-quoting-${qid.toLowerCase()}`, weird);
  const alpha = project(f, 'alpha');
  for (const a of [['install'], ['project', 'add', alpha], ['schedule', 'on', '--project', 'alpha'], ['schedule', 'on']]) {
    const r = f.cli(a); if (r.code !== 0) throw new Error(`${a.join(' ')}: ${r.all}`);
  }
  const text = readText(f.p.tickService);
  const u = parseService(text);
  const cfg = readJSON(f.p.scheduleConfig);
  check(`${qid}.1`, JSON.stringify(u.argv) === JSON.stringify([NODE, join(f.p.app, 'cli/bin/factory.mts'), 'tick']), `ExecStart parses back to ${JSON.stringify(u.argv)}`, 'ExecStart quoting/escaping (\\, ", %%, $$) round-trips exactly under systemd rules');
  check(`${qid}.2`, u.env.PATH === cfg.path && u.env.FACTORY_HOME === f.home && u.env.SANDCASTLE_STATE_DIR === f.p.state, `Environment parses back to ${JSON.stringify(u.env)}`, 'Environment= quoting round-trips; no $ expansion, % escaped');
  const execLine = text.split('\n').find(l => l.startsWith('ExecStart='))!;
  check(`${qid}.3`, /%%e/.test(execLine) && /\$\$X/.test(execLine) && (!runIt || (/\$\$HOME/.test(execLine) && /%%h/.test(execLine))), `ExecStart line ${execLine}`, 'specifiers and variables in paths are escaped, not expanded');
  if (runIt) {
    const t = f.startTick();
    const e = await t.exit;
    const runFile = join(f.out, 'alpha.run-1.txt');
    const run = existsSync(runFile) ? readText(runFile) : '';
    check(`${qid}.4`, e.code === 0 && run.includes(`SANDCASTLE_STATE_DIR=${f.p.state}\n`) && run.includes(`PATH=${cfg.path}\n`), `tick launched from the parsed unit exit ${e.code}; pass got the exact state and PATH`, 'the generated unit actually runs the installed app with the special-character paths', t.log());
  }
  check(`${qid}.5`, f.cli(['uninstall']).code === 0 && !existsSync(f.p.tickService), 'uninstall works with the hostile home', 'removal uses exact paths');
  check(`${qid}.6`, f.rejected().length === 0, 'stub rejected nothing', 'only expected calls');
}

section('O: opt-in refusals, via the real CLI');
{
  const f = fixture('s6-optin');
  f.cli(['install']);
  const noOrigin = project(f, 'noorigin', { origin: false });
  const localOnly = project(f, 'localonly');
  git(localOnly, 'checkout', '-q', '-b', 'feature-local');
  const notExec = project(f, 'notexec', { exec: false });
  const old = project(f, 'oldcopy', { current: false });
  const detached = project(f, 'detached');
  git(detached, 'checkout', '-q', '--detach');
  const good = project(f, 'good');
  for (const r of [noOrigin, localOnly, notExec, old, detached, good]) f.cli(['project', 'add', r]);
  const before = readText(f.p.projects);
  const cases: [string, RegExp, string][] = [
    ['noorigin', /no `origin` remote/, 'a checkout with no origin'],
    ['localonly', /branch feature-local is not on origin/, 'a branch absent from origin'],
    ['notexec', /is not executable/, 'a non-executable dispatch.sh'],
    ['oldcopy', /predates launch reservations/, 'an old dispatcher copy (missing the #32 reserveRun protocol)'],
    ['detached', /detached HEAD/, 'a detached HEAD'],
  ];
  for (const [name, re, what] of cases) {
    const r = f.cli(['schedule', 'on', '--project', name]);
    check(`O.${name}`, r.code !== 0 && re.test(r.all), `refuses ${what}: ${r.all.split('\n').find(l => re.test(l))?.trim()}`, 'opt-in validates origin branch, executable script, protocol and named branch', r.all);
  }
  check('O.unchanged', readText(f.p.projects) === before, 'registry unchanged by refusals', 'refused opt-ins write nothing');
  let r = f.cli(['schedule', 'on', '--project', 'good']);
  check('O.good', r.code === 0 && readJSON(f.p.projects).projects.find((x: any) => x.name === 'good').schedule.branch === 'main', 'a valid project opts in on main', 'positive control');
  git(good, 'checkout', '-q', '-b', 'topic'); git(good, 'push', '-q', 'origin', 'topic');
  r = f.cli(['schedule', 'on', '--project', 'good']);
  check('O.refresh', r.code === 0 && readJSON(f.p.projects).projects.find((x: any) => x.name === 'good').schedule.branch === 'topic', 'repeated opt-in refreshes the saved branch', 'repeat project on refreshes the branch');
  git(good, 'checkout', '-q', 'main');
  // Deleted checkout can be paused by its recorded path, without touching files.
  renameSync(good, good + '.moved');
  r = f.cli(['schedule', 'off', '--project', good]);
  const g = readJSON(f.p.projects).projects.find((x: any) => x.name === 'good');
  check('O.deleted', r.code === 0 && g.schedule.enabled === false && g.schedule.branch === 'topic', `paused deleted checkout: ${JSON.stringify(g.schedule)}`, 'project off is registry-only, works for a deleted checkout, and keeps the saved branch');
  renameSync(good + '.moved', good);
}

section('B: saved-branch guard and failed-pass exit status');
{
  const { f, roots } = setup('s6-branch', [{ name: 'alpha', script: rec('alpha') }, { name: 'beta', script: rec('beta', 3) }, { name: 'gamma', script: rec('gamma') }]);
  git(roots.alpha, 'checkout', '-q', '-b', 'other');
  writeFileSync(join(roots.alpha, 'dirty.txt'), 'uncommitted\n');
  const head = git(roots.alpha, 'rev-parse', 'HEAD'); const status = git(roots.alpha, 'status', '--porcelain'); const stash = git(roots.alpha, 'stash', 'list');
  const mark = f.calls().length;
  const t = f.startTick();
  const e = await t.exit;
  const s = readJSON(f.p.stateJson);
  check('B.1', s.projects[roots.alpha].result === 'skipped' && /checkout is on other, scheduled branch is main/.test(s.projects[roots.alpha].reason) && !existsSync(join(f.out, 'alpha.count')),
    `alpha skipped: ${s.projects[roots.alpha].reason}`, 'a changed branch blocks the pass');
  check('B.2', git(roots.alpha, 'rev-parse', '--abbrev-ref', 'HEAD') === 'other' && git(roots.alpha, 'rev-parse', 'HEAD') === head && git(roots.alpha, 'status', '--porcelain') === status && git(roots.alpha, 'stash', 'list') === stash,
    'alpha branch, HEAD, worktree status and stash unchanged', 'the tick never checks out, resets, pulls or stashes');
  check('B.3', e.code === 1 && s.projects[roots.beta].result === 'error' && s.projects[roots.beta].exitCode === 3 && /failed/.test(t.log()),
    `tick exit ${e.code}; beta ${JSON.stringify(s.projects[roots.beta])}`, 'a failed project pass makes the tick exit nonzero');
  check('B.4', s.projects[roots.gamma].result === 'ok' && existsSync(join(f.out, 'gamma.count')), 'gamma (after the failure) still ran', 'one project error does not hide later healthy work (traversal as implemented)');
  check('B.5', f.mutating(mark).length === 0 && f.unit('factory-tick.timer').enabled && f.unit('factory-tick.timer').active, 'no systemctl mutation by the failing tick; timer still enabled+active', 'a failed tick does not disable future retries (rearming itself is trusted systemd behaviour)');
}

section('C: CLI argument contract');
{
  const f = fixture('s6-cli');
  f.cli(['install']);
  const alpha = project(f, 'alpha');
  f.cli(['project', 'add', alpha]);
  const bad: [string[], RegExp, string][] = [
    [['schedule', 'on', 'alpha'], /Unexpected arguments/, 'positional project'],
    [['schedule', 'on', '--json'], /--json applies to schedule status/, '--json with on'],
    [['schedule', 'off', '--json'], /--json applies to schedule status/, '--json with off'],
    [['schedule', 'enable'], /Usage: factory schedule/, 'unknown action'],
    [['schedule'], /Usage: factory schedule/, 'missing action'],
    [['tick', '--max', '9'], /Unknown option|Unexpected/, 'tick takes no public dispatch flags'],
    [['tick', 'alpha'], /Unexpected arguments/, 'tick takes no project argument'],
    [['schedule', 'on', '--project'], /argument missing|requires|Option/, '--project without a value'],
  ];
  const mark = f.calls().length;
  for (const [args, re, what] of bad) { const r = f.cli(args); check(`C.${what}`, r.code !== 0 && re.test(r.all), `rejects ${what}: ${r.all.trim().split('\n').slice(-2, -1)[0] ?? r.all.trim()}`, 'per-command argument contract', r.all); }
  check('C.nocalls', f.mutating(mark).length === 0 && !existsSync(f.p.tickTimer), 'rejected invocations changed nothing', 'argument errors are side-effect free');
  const r = f.cli(['schedule', 'on', '--project', alpha + '/.sandcastle']);
  check('C.path-inside', r.code === 0 && readJSON(f.p.projects).projects[0].schedule?.enabled === true, '--project accepts a path inside the checkout', '--project <path> contract');
}

section('L: one tick per user');
{
  const { f, roots } = setup('s6-lock', [{ name: 'alpha', script: hold({ seconds: 4 }) }]);
  const { t, pids } = await startHeld(f, 'L');
  const t2 = f.startTick();
  const e2 = await t2.exit;
  check('L.1', e2.code === 0 && /another tick is running/.test(t2.log()) && readText(join(f.out, 'alpha.pass')).trim() === String(pids.pass), `second tick: ${t2.log().trim()}`, 'a second tick does no work while one holds the lock');
  await t.exit;
  writeFileSync(f.p.lock, 'garbage');
  const t3 = f.startTick();
  const e3 = await t3.exit;
  check('L.2', e3.code !== 0 && /unreadable/.test(t3.log()), `malformed lock: exit ${e3.code}`, 'an unreadable lock fails closed', t3.log());
  try { process.kill(pids.ticket, 'SIGKILL'); } catch {}
}
finish('s6-contracts');
