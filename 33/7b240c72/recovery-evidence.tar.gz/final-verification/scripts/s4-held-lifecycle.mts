// S4: cancellation-only escalation vs. no pass timeout, and reinstall/uninstall/dry-run while a pass is held.
//  A  a pass group that ignores SIGTERM: `schedule off` escalates to SIGKILL on that group only after the grace period.
//  B  (in parallel with A) a normal pass that runs 45 s, longer than grace+confirm+margin: never signalled, ends ok.
//  C  uninstall --dry-run while a pass is held: no call, no signal, no file change.
//  D  reinstall (`factory install` again) while a pass is held: stop scheduling + cancel first, units refreshed, timer
//     left disabled, no tick enable, opt-ins kept, detached ticket alive.
//  E  uninstall while a pass is held: cancellation confirmed before any unit/app removal; ticket run and history kept.
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { alive, bystanders, check, finish, killAll, readJSON, section, sleep, waitFor } from './lib.mts';
import { hold, rec, setup, startHeld } from './setup.mts';

const A = async () => {
  const out: string[] = [];
  const { f, roots } = setup('s4a-escalate', [{ name: 'alpha', script: hold({ ignoreTerm: true }) }, { name: 'beta', script: rec('beta') }]);
  const by = bystanders(f);
  const { t, pids } = await startHeld(f, 'S4A');
  const t0 = Date.now();
  const r = f.cli(['schedule', 'off']);
  const took = Date.now() - t0;
  const e = await t.exit;
  return () => {
    check('S4A.1', r.code === 0 && took >= 29_000 && took < 60_000, `off took ${took} ms with a SIGTERM-ignoring pass (exit ${r.code})`, 'escalation waits the cancellation grace (30 s) and is bounded', r.all);
    check('S4A.2', !alive(pids.pass) && !alive(pids.nested) && !alive(pids.analysis) && !alive(pids.analysisChild) && alive(pids.ticket),
      'SIGTERM-ignoring owned group is gone (SIGKILL), detached ticket alive', 'escalation stays confined to the owned dispatcher group and preserves detached ticket groups');
    check('S4A.3', alive(by.pids.ownSession) && alive(by.pids.verifierGroup) && alive(by.pids.unrelatedNode), 'bystanders alive', 'no broad kill during escalation');
    const a = readJSON(f.p.stateJson).projects[roots.alpha];
    check('S4A.4', e.code === 143 && a.result === 'interrupted' && !existsSync(join(f.out, 'beta.count')), `tick exit ${e.code}; alpha ${JSON.stringify(a)}`, 'escalated cancellation still records interruption and starts nothing later');
    killAll([pids.ticket]); by.kill();
  };
};
const B = async () => {
  const { f, roots } = setup('s4b-long-pass', [{ name: 'alpha', script: hold({ seconds: 45 }) }]);
  const { t, pids } = await startHeld(f, 'S4B');
  const t0 = Date.now();
  const e = await t.exit;
  const took = Date.now() - t0;
  return () => {
    const a = readJSON(f.p.stateJson).projects[roots.alpha];
    check('S4B.1', e.code === 0 && a.durationMs >= 44_000 && a.result === 'ok' && a.exitCode === 0 && existsSync(join(f.out, 'alpha.done')),
      `45 s pass ended normally (recorded durationMs ${a.durationMs}; verifier saw exit ${took} ms after ready): tick exit ${e.code}, ${JSON.stringify(a)}`, 'no automatic pass timeout: the cancellation grace never applies to a normally running pass');
    check('S4B.2', alive(pids.ticket), 'detached ticket alive after the pass finished', 'finishing a pass does not touch detached runs');
    killAll([pids.ticket, pids.nested, pids.analysis, pids.analysisChild]);
  };
};
section('A + B (run concurrently): escalation on cancellation only; no timeout on a running pass');
const [ca, cb] = await Promise.all([A(), B()]);
ca(); cb();

section('C: uninstall --dry-run with a held pass');
{
  const { f, roots } = setup('s4c-dryrun', [{ name: 'alpha', script: hold() }]);
  const { t, pids } = await startHeld(f, 'S4C');
  const mark = f.calls().length;
  const before = f.treeHash();
  const r = f.cli(['uninstall', '--dry-run']);
  check('S4C.1', r.code === 0 && f.calls().length === mark && f.treeHash() === before, `dry-run: ${f.calls().length - mark} calls, tree unchanged=${f.treeHash() === before}`, 'dry-run makes no manager call and changes nothing even with a tick running', r.all);
  check('S4C.2', alive(t.pid) && alive(pids.pass) && alive(pids.analysisChild) && readJSON(f.p.stateJson).projects[roots.alpha].result === 'running', 'tick and pass tree untouched', 'dry-run signals nothing');
  process.kill(t.pid, 'SIGTERM'); await t.exit; killAll([pids.ticket]);
}

section('D: reinstall while a pass is held');
{
  const { f, roots } = setup('s4d-reinstall', [{ name: 'alpha', script: hold() }, { name: 'beta', script: rec('beta') }]);
  const { t, pids, record } = await startHeld(f, 'S4D');
  f.watch({ tick: t.pid, ...pids });
  const svcBefore = readFileSync(f.p.tickService, 'utf8');
  const mark = f.calls().length;
  const r = f.cli(['install']);
  const calls = f.calls().slice(mark);
  const lines = calls.map((c: any) => c.argv.slice(1).join(' '));
  const dis = calls.find((c: any) => c.argv.slice(1).join(' ') === 'disable --now factory-tick.timer');
  const firstBoard = calls.findIndex((c: any) => c.argv.slice(1).join(' ') === 'enable factory-board.service');
  check('S4D.1', r.code === 0, 'reinstall exits 0', 'reinstall works with scheduler artifacts present', r.all);
  check('S4D.2', dis && dis.watch.tick && dis.watch.pass && lines.indexOf('disable --now factory-tick.timer') < lines.indexOf('stop factory-tick.service') && lines.indexOf('stop factory-tick.service') < firstBoard,
    `reinstall calls ${JSON.stringify(lines)}`, 'reinstall disables/stops the timer and the tick before touching board/app');
  check('S4D.3', calls[firstBoard]?.watch && !calls[firstBoard].watch.tick && !calls[firstBoard].watch.pass && !calls[firstBoard].watch.analysisChild,
    'the owned tick/pass tree was already gone when the board was reinstalled', 'cancellation is confirmed before owned runtime files are replaced');
  check('S4D.4', !lines.includes('enable --now factory-tick.timer') && !lines.some(l => /^(enable|start|restart) factory-tick/.test(l)) && !f.unit('factory-tick.timer').enabled && !f.unit('factory-tick.timer').active,
    'no tick enable/start; stub timer disabled and inactive', 'reinstall leaves the actual timer disabled; explicit on is needed to resume');
  const m = readJSON(f.p.manifest);
  const units = m.entries.filter((e: any) => e.kind === 'systemd').map((e: any) => e.unit);
  check('S4D.5', existsSync(f.p.tickService) && existsSync(f.p.tickTimer) && JSON.stringify(units.sort()) === JSON.stringify(['factory-board.service', 'factory-tick.service', 'factory-tick.timer']) && readFileSync(f.p.tickService, 'utf8') === svcBefore,
    `units refreshed and ledgered once each: ${JSON.stringify(units)}`, 'reinstall refreshes only owned scheduler artifacts and keeps exact ledger identities');
  check('S4D.6', alive(pids.ticket) && readFileSync(join(f.p.state, 'synthetic-alpha-1.json'), 'utf8') === record && readJSON(f.p.projects).projects.every((x: any) => x.schedule?.enabled === true),
    'detached ticket alive with record; both opt-ins kept', 'reinstall preserves detached runs and project opt-in but does not re-enable scheduling');
  check('S4D.7', /The scheduler is off\. Resume it with: factory schedule on/.test(r.out) && /Its pass for alpha was cancelled/.test(r.out), 'reinstall reports the cancellation and that the scheduler is off', 'honest reporting', r.out);
  const e = await t.exit;
  check('S4D.8', e.code === 143 && !existsSync(join(f.out, 'beta.count')), `tick exit ${e.code}; beta not run`, 'no later work after reinstall cancellation');
  const st = JSON.parse(f.cli(['schedule', 'status', '--json']).out);
  check('S4D.9', st.scheduler.phase === 'off' && st.scheduler.serviceEnabled === false, `status after reinstall phase=${st.scheduler.phase}`, 'status reflects the disabled timer');
  killAll([pids.ticket]);
}

section('E: uninstall while a pass is held');
{
  const { f, roots } = setup('s4e-uninstall', [{ name: 'alpha', script: hold() }, { name: 'beta', script: rec('beta') }]);
  const by = bystanders(f);
  const { t, pids, record } = await startHeld(f, 'S4E');
  f.watch({ tick: t.pid, ...pids });
  const mark = f.calls().length;
  const r = f.cli(['uninstall']);
  const calls = f.calls().slice(mark);
  const lines = calls.map((c: any) => c.argv.slice(1).join(' '));
  const dis = calls.find((c: any) => c.argv.slice(1).join(' ') === 'disable --now factory-tick.timer');
  const firstRemove = calls.find((c: any) => c.argv.slice(1).join(' ') === 'stop factory-tick.timer');
  check('S4E.1', r.code === 0, 'uninstall exits 0', 'uninstall completes after confirmed cancellation', r.all);
  check('S4E.2', dis?.watch.tick && dis?.watch.pass && dis.files['factory-tick.timer'], 'at disable --now the tick, pass and unit files all existed', 'uninstall disables/stops future activation first');
  check('S4E.3', firstRemove && !firstRemove.watch.tick && !firstRemove.watch.pass && !firstRemove.watch.nested && !firstRemove.watch.analysisChild && firstRemove.files['factory-tick.timer'] && firstRemove.watch.ticket,
    `at the first unit removal call: tick=${firstRemove?.watch.tick} pass=${firstRemove?.watch.pass} ticket=${firstRemove?.watch.ticket}`, 'exact ledgered units are removed only after the tick/pass cancellation was acknowledged');
  check('S4E.4', !existsSync(f.p.tickService) && !existsSync(f.p.tickTimer) && !existsSync(f.p.app) && !existsSync(f.p.manifest) && existsSync(f.p.stateJson) && existsSync(f.p.projects) && existsSync(f.p.scheduleConfig),
    'units, app and manifest removed; state, registry and launch config kept', 'uninstall removes exact ledger entries and keeps retained config/history');
  check('S4E.5', alive(pids.ticket) && readFileSync(join(f.p.state, 'synthetic-alpha-1.json'), 'utf8') === record && alive(by.pids.ownSession) && alive(by.pids.verifierGroup) && alive(by.pids.unrelatedNode),
    'detached ticket alive with its record; bystanders alive', 'uninstall preserves detached runs and unrelated processes');
  const a = readJSON(f.p.stateJson).projects[roots.alpha];
  const e = await t.exit;
  check('S4E.6', e.code === 143 && a.result === 'interrupted' && !existsSync(join(f.out, 'beta.count')) && /cancelled and recorded as interrupted/.test(r.out), `tick ${e.code}; alpha ${a.result}; message ok`, 'interrupted state and honest uninstall report; no later project');
  check('S4E.7', f.rejected().length === 0, 'stub rejected nothing', 'only expected calls');
  killAll([pids.ticket]); by.kill();
}
finish('s4-held-lifecycle');
