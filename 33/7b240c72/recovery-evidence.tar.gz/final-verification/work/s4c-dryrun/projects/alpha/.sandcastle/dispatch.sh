#!/bin/sh
O='/recovery/evidence/final-verification/work/s4c-dryrun/out'
echo $$ > "$O/alpha.pass"
sh -c 'exec sleep 300' &
echo $! > "$O/alpha.nested"
'/usr/local/bin/node' -e "const c=require('child_process').spawn('sleep',['300'],{stdio:'ignore'});require('fs').writeFileSync(process.argv[1]+'/alpha.analysis-child',String(c.pid));setInterval(()=>{},1e6)" "$O" &
echo $! > "$O/alpha.analysis"
'/usr/local/bin/node' -e "const c=require('child_process').spawn('sleep',['300'],{detached:true,stdio:'ignore'});c.unref();const fs=require('fs');fs.writeFileSync(process.argv[1]+'/alpha.ticket',String(c.pid));fs.writeFileSync(process.env.SANDCASTLE_STATE_DIR+'/synthetic-alpha-1.json',JSON.stringify({stage:'setup',note:'starting',starting:true,pid:c.pid}))" "$O"
while [ ! -s "$O/alpha.analysis-child" ]; do sleep 0.05; done
echo ready > "$O/alpha.ready"
wait
