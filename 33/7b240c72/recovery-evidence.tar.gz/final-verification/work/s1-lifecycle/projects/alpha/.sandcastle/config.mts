export const TRACKER = {
  project: "synthetic/alpha",
};
