export const TRACKER = {
  project: "synthetic/beta",
};
