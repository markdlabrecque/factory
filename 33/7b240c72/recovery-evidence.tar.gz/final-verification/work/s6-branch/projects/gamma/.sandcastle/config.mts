export const TRACKER = {
  project: "synthetic/gamma",
};
