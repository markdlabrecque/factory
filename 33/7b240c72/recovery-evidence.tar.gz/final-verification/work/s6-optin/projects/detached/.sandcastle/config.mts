export const TRACKER = {
  project: "synthetic/detached",
};
