export const TRACKER = {
  project: "synthetic/localonly",
};
