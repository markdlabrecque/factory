#!/bin/sh
O='/recovery/evidence/final-verification/work/s6-optin/out'
n=$(cat "$O/localonly.count" 2>/dev/null || echo 0); n=$((n+1)); echo $n > "$O/localonly.count"
{
  echo "pid=$$"; echo "cwd=$(pwd)"; echo "argc=$#"; for a in "$@"; do echo "arg=$a"; done
  echo "PATH=$PATH"; echo "SANDCASTLE_STATE_DIR=${SANDCASTLE_STATE_DIR-<unset>}"; echo "FACTORY_SCHEDULED=${FACTORY_SCHEDULED-<unset>}"
  if [ -t 0 ]; then echo stdin_tty=yes; else echo stdin_tty=no; fi
  echo "pgid=$(cut -d' ' -f5 /proc/$$/stat)"; echo "sid=$(cut -d' ' -f6 /proc/$$/stat)"
} > "$O/localonly.run-$n.txt"
exit 0
