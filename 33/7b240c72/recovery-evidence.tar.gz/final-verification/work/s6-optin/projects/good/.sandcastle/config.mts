export const TRACKER = {
  project: "synthetic/good",
};
