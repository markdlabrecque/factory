export const TRACKER = {
  project: "synthetic/noorigin",
};
