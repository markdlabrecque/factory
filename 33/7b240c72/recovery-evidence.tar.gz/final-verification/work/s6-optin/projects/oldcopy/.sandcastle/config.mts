export const TRACKER = {
  project: "synthetic/oldcopy",
};
