VERDICT: FAIL

# #33 recovery, re-review of review-0 findings (reviewer-1)

Scope: only the four numbered findings in `/recovery/review-0.md`. I didn't restart the full review.

Findings 3 and 4 are resolved. Findings 1 and 2 work for every scenario I asked for, and my review-0 probes now show the fixed behaviour. Each still has a small residual that falls inside the original finding. Finding 1 can still name the wrong project in a narrow race (probe R1-a). Finding 2 skipped part of the requested doc update, and it mislabels one edge case in state.json. All three residuals are small and listed under "Remaining actions". Nothing else blocks.

## Tested revision

- HEAD `991180a96ad63918ece3aea5f6323f7224549029`, unchanged. Branch `33-deliver-the-linux-schedule-enable-to-uni`. PR base `dbfd2f35d25e792e5ef5c093edde5e76f8911b6d`.
- Tree: HEAD plus the uncommitted round-2 diff. It's the same file set as in review-0: 20 tracked files changed and 10 untracked files.
- Fingerprint, computed the same way as in review-0 (`git diff HEAD`, then each untracked file's contents sorted by path, piped to sha256): `d314a914cde594d76992234c8d2d4402956134602687b344a16c2c3a2869ca34`. The review-0 tree was `83e36a9c...`. The implementor's snapshot is `/recovery/evidence/uncommitted-round2.patch`.
- I inspected the round-2 fix by diffing `/recovery/evidence/uncommitted.patch` against `uncommitted-round2.patch` and by reading the current `cli/src/commands/schedule.mts`, `cli/src/commands/tick.mts`, `cli/src/tick-lock.mts`, `cli/src/commands/uninstall.mts`, `cli/src/commands/install.mts`, the new tests in `cli/test/schedule-linux.test.mts` (lines 678-866), `TESTING.md`, `docs/factory-cli.md` and `README.md`.
- Node v22.23.4, Linux, no systemd. I didn't modify, stage or commit any worktree file. I wrote only `/recovery/evidence/review-1/*` and this report.

## Commands and results

| Command | Result |
| --- | --- |
| `node --test orchestrator/*.test.mts board/*.test.mts cli/test/*.test.mts` | 117 pass, 0 fail. `/recovery/evidence/review-1/full-suite.tap` |
| `node --test cli/test/schedule-linux.test.mts cli/test/scheduler.test.mts cli/test/schedule.test.mts`, twice | 51 pass, 0 fail both times. `/recovery/evidence/review-1/focused-reruns.txt`. Afterwards no stray `sleep 300` or leftover loop processes were running. |
| Rerun of my review-0 probes, `node --test /recovery/evidence/review-0/probes.test.mts` | P-A, P-B and P-E still hold. P-C and P-D now fail, because they asserted the old defective behaviour. P-C prints `The active tick was stopped.`, and P-D shows the leftover process dead and its group empty. `/recovery/evidence/review-1/review-0-probes-rerun.txt` |
| `node --test /recovery/evidence/review-1/probes.test.mts` (new probe R1-a, in-memory `FakeSchedule`) | Confirms residual 1a. `/recovery/evidence/review-1/probes.txt` |
| Read `/recovery/evidence/mutation-checks-round2.txt` (implementor's evidence, not rerun) | M13 to M18 each made at least one named test fail |

## Disposition per finding

### 1. `off` said "No tick was running" after systemd's stop cancelled the tick: mostly resolved, one residual

What was fixed:

- `stopScheduling` (`cli/src/commands/schedule.mts:75-88`) reads the manager's tick state before it disables anything. A failed read is recorded as unknown and does not prevent the stop.
- It records which projects had a `running` entry before the stop and which are no longer running afterwards, and returns that as a `StopReport`.
- `describeStop` (`:90-97`) prints "The active tick was stopped." when the manager reported a tick or Factory cancelled one. It prints the unknown sentence when the manager can't be read, and "No tick was running." only when nothing showed a tick.
- `off`, uninstall (`uninstall.mts:39`) and reinstall (`install.mts:48`) all print this message.

Evidence:

- The test "off reports a tick the service stop cancelled ..." uses the stub, with the tick service active and no lock.
- The test "off reports the cancelled project when systemd's stop ... ends the tick and releases its lock" uses a `FakeSchedule.onStop` hook that SIGTERMs a held tick and waits for it. The exact message names `alpha`, and the detached ticket run survives.
- The test "off says the state is unknown ..." covers a failed manager read.
- The stub signals no processes, which keeps to the stub boundary.
- Mutations M14 and M15 are caught. Rerunning P-C now gives `The active tick was stopped.`

**Residual 1a (still open, low).** `interrupted` is computed as `before.filter(root => !after.has(root))` (`schedule.mts:87`). That counts every entry that stopped being `running`, not only entries that became `interrupted`. A pass can finish normally (`ok` or `error`) between the pre-stop read and the moment systemd's SIGTERM reaches the tick. In that case `off` still prints "Its pass for X was cancelled and recorded as interrupted" while state.json records `ok`. Probe R1-a reproduces this: the state says `ok` and the message claims cancelled and interrupted. The window is short, but this is the dishonest reporting finding 1 was about. The fourth branch of `describeStop` (`:94`) has the same problem.

### 2. Ownership of a pass group was dropped while members were alive: behaviour resolved, docs and one state record still open

What was fixed:

- After the pass leader exits, `runPass` (`cli/src/commands/tick.mts:192-201`) checks `passAlive(lock.info.pass)`.
- If members are still alive, it logs that and runs `terminateGroup` on that group only (SIGTERM, grace, SIGKILL). `clearPass` runs only after the group has been confirmed gone.
- The reason is recorded (`left processes running in its process group, terminated`, plus `with SIGKILL` when SIGKILL was needed).
- If termination can't be confirmed, the lock keeps the group, the tick exits 1, and a later tick is `busy`.
- An abort during that termination doesn't start a second termination, and the loop's abort check still ends the tick.
- Detached ticket runs are in their own groups and survive. This is the "terminate" option I allowed in review-0. It's confined to the owned group and only runs after the leader has exited, so it's not a pass timeout.

Evidence:

- The test "a pass that exits leaving a non-detached child has that group terminated ..." runs the real CLI tick.
- The test "a leftover that ignores SIGTERM is killed after the grace period ...; one that cannot be killed keeps ownership recorded" covers the SIGKILL case and the unconfirmed case.
- Mutations M13 and M18 are caught. Rerunning P-D shows the leftover dead and the group empty.
- The `tick-lock.mts` header (lines 10-11), the `docs/factory-cli.md` cancellation paragraph and the README were updated.

**Residual 2a (still open, low, docs).** I asked for the tick header comment to be updated as well. `cli/src/commands/tick.mts:1-20` still describes the pass record and cancellation as before, with no mention that the tick terminates a finished pass's leftover group or what it records. The explanation exists only as an inline comment at `:192-195`. AGENTS.md requires the top comment of a touched file to describe the change, and the implementation report says this header was updated.

**Residual 2b (still open, low).** When leftover termination can't be confirmed, `runPass` returns `{ code, unconfirmed }` (`:200`). The tick then records the pass as `result: 'interrupted'`, deletes `finishedAt` and `durationMs`, and never sets `exitCode`, because the early return at `:131-137` skips line 148. But the leader really did exit, with an observed code, finish time and duration. state.json therefore says a pass was interrupted when it actually completed, and it discards the observed exit data. That conflicts with the contract's "record ... results honestly and flush available timing data".

### 3. Failed enable and partial installation untested through the production adapter: resolved

Three new CLI tests run against the stub (`schedule-linux.test.mts:810-866`):

- A `once:` failure on `enable --now` exits non-zero, reports the manager's state, keeps both units in the ledger, writes no `enabled` member, makes exactly the expected calls, and a retry succeeds without duplicates.
- A `once:` failure on `daemon-reload` never attempts enable, keeps both units in the ledger, and uninstall then removes them by exact identity with an exact call list.
- Running `schedule on` twice makes the same two mutating calls each time, ledgers once, and the stub rejects nothing.

Mutations M16 (enable without `--now`) and M17 (no `daemon-reload`) are caught. This matches what I requested.

### 4. Docs conflicted with the cancellation contract and the slice status: resolved

- `TESTING.md` lines 1-67 match `/recovery/testing-policy.md` exactly (checked with `diff`).
- One paragraph at the start of "In this repository" reconciles the policy sentence with the approved #30/#33 contract, as requested.
- The `docs/factory-cli.md:4` status line now says slice four is partly implemented and lists what is still proposed.
- No em dashes were added.

## Remaining actions (scope for the next re-review)

1. **Residual 1a.**
   - **Fix:** name only projects whose entry is `interrupted` after the stop. For example, collect `after` as a map of root to result and keep `before` roots whose result is now `interrupted`. A pass that finished normally during the stop is not described as cancelled. Optionally, mention it as "finished before the stop".
   - **Verify:** add a regression test like R1-a (an `onStop` hook that rewrites the running entry to `ok`) and assert the message doesn't claim it was cancelled. The existing finding-1 tests must still pass.
2. **Residual 2a.**
   - **Fix:** add the leftover-group termination to the top comment of `cli/src/commands/tick.mts`: when it happens, that it's confined to the owned group, that it's not a pass timeout, what state.json records, and that an unconfirmed termination keeps the lock and makes the tick exit 1.
   - **Verify:** read the header.
3. **Residual 2b.**
   - **Fix:** in the unconfirmed-leftover case, keep the observed outcome. `result` should follow the exit code (`ok` or `error`), with `exitCode`, `finishedAt` and `durationMs` set, and a reason saying the leftover group's termination is unconfirmed. The lock is still kept and the tick still exits 1. Use `interrupted` only for a cancellation that was actually requested.
   - **Verify:** extend "a leftover that ignores SIGTERM ... cannot be killed keeps ownership recorded" to assert `result`, `exitCode`, `finishedAt` and `durationMs` for that case, plus the existing lock and `busy` checks.

## Limitations

- The stub boundary is unchanged. systemd's stop delivering SIGTERM to the tick and waiting for it is trusted and documented, not proven. In the tests a `FakeSchedule` hook or the test itself sends that SIGTERM.
- I didn't rerun the implementor's round-2 mutation script. I read its output and checked that the named tests exist and assert the claimed behaviour.
- `/proc`-based process identity is Linux only. macOS is #35.
