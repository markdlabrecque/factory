VERDICT: FAIL

# #33 recovery, independent initial review (reviewer-0)

Most of the recovery holds up. The service manager is now the only global authority, off disables the timer before it cancels anything, the pass runs in its own group, a detached ticket run survives, and failed stops leave the ledger and files in place. The full suite passes and I found no regressions in board/run/dispatch. Four findings remain against the current contract. Two are Factory behaviour I reproduced with probes: off misreports a cancelled tick, and a pass group's ownership is dropped while members of that group are still alive. One is a required stub-level test that is missing. One is a doc conflict. The numbered list below is the scope for re-review.

## Tested revision

- Branch `33-deliver-the-linux-schedule-enable-to-uni`, HEAD `991180a96ad63918ece3aea5f6323f7224549029`, unchanged. PR base `dbfd2f35d25e792e5ef5c093edde5e76f8911b6d`.
- Tree under test: HEAD plus the uncommitted recovery. 20 tracked files changed (774+, 470-), `cli/src/tick.mts` deleted, and 10 untracked files: `TESTING.md`, `cli/src/commands/tick.mts`, `cli/src/platform/scheduler.mts`, `cli/src/platform/scheduler-systemd.mts`, `cli/src/schedule-state.mts`, `cli/src/tick-cancel.mts`, `cli/src/tick-lock.mts`, `cli/test/schedule-helpers.mts`, `cli/test/schedule-linux.test.mts` and `cli/test/stubs/systemctl`.
- Fingerprint of `git diff HEAD` followed by each untracked file's contents (sorted by path): sha256 `83e36a9c31e937031d0c4c97e4234aa3c1cb09e2c1aacd196d7b2bf8af7c2b6f`. Re-review should recompute it the same way to confirm the same tree, or diff against it.
- I reviewed the full diff against the PR base (`git diff dbfd2f3`, plus the untracked files), the original feature commit `991180a`, and the recovery delta (`git diff HEAD`). `cli/src/platform/{index,systemd,launchd}.mts` now match the base again, so board controls are unchanged from main.
- `origin/main` is now `82bec2c`, three #46 doc commits past the PR base. They touch `AGENTS.md`, `README.md`, `docs/factory-cli.md`, `orchestrator/ADAPTING.md` and `skills/sandcastle-setup/SKILL.md`. That isn't a defect in this change. Expect conflicts in the shared docs when the branch is rebased or merged.
- Node v22.23.4, Linux, no systemd and no host sockets. Every `systemctl` call went to the test-owned stub. I didn't modify, stage or commit any worktree file. `git status` matches the start of the session.

## Commands and results

| Command | Result |
| --- | --- |
| `node --test orchestrator/*.test.mts board/*.test.mts cli/test/*.test.mts` | 109 pass, 0 fail. `/recovery/evidence/review-0/full-suite.tap` |
| `node --test cli/test/schedule-linux.test.mts cli/test/scheduler.test.mts cli/test/schedule.test.mts`, twice | 43 pass, 0 fail both times. `/recovery/evidence/review-0/focused-reruns.txt` |
| `node --test /recovery/evidence/review-0/probes.test.mts` (my probes: real CLI and production adapter against `cli/test/stubs/systemctl`, synthetic processes) | 5 probes ran. Their assertions describe what I observed, so a "pass" means "observed as described", not "correct". `/recovery/evidence/review-0/probes.txt` |

Probe results:

- **P-A.** A failed `enable --now factory-tick.timer` exits 1 and keeps both units in the ledger. The error says `Scheduler state now: timer disabled/inactive, tick service inactive` and `schedule.json` has no enabled flag. A second `schedule on` succeeds, and uninstall then cleans up. The behaviour is correct, but no repository test covers it through the stub (finding 3).
- **P-B.** A failed `daemon-reload` during `on` leaves both units in the ledger, and uninstall removes them with exact calls. Correct, but untested at stub level (finding 3).
- **P-C.** The manager reports the tick service active and no Factory lock exists. `schedule off` prints `No tick was running.` (finding 1).
- **P-D.** A dispatcher backgrounds `sleep 300` without detaching, then exits 0. The tick logs `ok` and deletes the lock, and the sleep stays alive in the owned pass group. Afterwards `schedule off` prints `No tick was running.` and the sleep survives (finding 2).
- **P-E.** A failed `show` gives `service:"unknown"` and `phase:"unknown"` in `status --json`, and `doctor` reports FAIL. Correct.

## Findings

### 1. `schedule off` says "No tick was running" when systemd's stop just cancelled one

- **Where:**
  - `cli/src/commands/schedule.mts:84-85`, where the message comes only from `cancelTick().active`.
  - `cli/src/tick-cancel.mts:56-58`, which returns `active:false` when no lock exists.
  - `cli/src/platform/scheduler-systemd.mts:83-86`, where `disable()` returns nothing about the tick service it stopped.
- **Failure:** On a real host the tick runs as `factory-tick.service`. `disable()` runs `systemctl --user stop factory-tick.service`, which (trusted, documented) sends the tick SIGTERM under `KillMode=process` and waits for it to exit. The tick cancels its pass, records it `interrupted` and releases its lock. `cancelTick` then finds no lock, and `off` prints `No tick was running.` So in the normal production path, the one off exists for, off tells the user nothing was cancelled while state.json says a pass was interrupted. P-C reproduces the report half with the stub. The contract asks for honest reporting of interrupted/cancelled results and acknowledgement before reporting completion. The current tests only cover a tick started outside systemd, where `cancelTick` itself sends the signal.
- **Requested fix:** Base the report on what the manager and Factory observed. For example, read `backend.status().tick` (and the lock/state.json) before `disable()`. If the tick service was active, or a running entry turned `interrupted` during off, say the active tick was stopped and its pass cancelled, naming the project when state.json has it. Report "no tick was running" only when neither the manager nor the lock showed one. Uninstall and reinstall share `stopScheduling`, so give their messages the same truth. If the manager query fails before off, say the state is unknown rather than guessing. Don't make the stub signal processes. That would simulate systemd.
- **Verification:**
  - A stub-level CLI test sets `factory-tick.service` `forcedActiveState: 'active'` with no lock and asserts that `off` does not claim no tick was running.
  - A `FakeSchedule` test whose `onStop` hook SIGTERMs a held tick (standing in for the stop) asserts that `off` reports the cancellation and the interrupted project.
  - The existing no-tick case still prints "No tick was running".

### 2. Ownership of a pass group is dropped while members of that group are still running

- **Where:**
  - `cli/src/commands/tick.mts:144`: `lock.clearPass()` runs whenever the leader exits, without checking `groupAlive(pid)`.
  - `cli/src/tick-lock.mts:100` (`clearPass`).
  - `cli/src/tick-cancel.mts:74`, which only sees what the lock records.
  - The implementor lists this as "escape by design" item 7.
- **Failure:** The contract says "Establish ownership/isolation before spawning so nested shell/npx/analysis processes cannot become untracked orphans." In P-D the dispatcher leaves a non-detached child in its own group (pgid = pass pid) and exits 0. The tick logs `ok`, deletes the ownership record and releases the lock. That owned process now has no record, `schedule off` and uninstall can't reach it, and under `KillMode=process` nothing else will. The real dispatcher hits this when it dies mid-`spawnSync` (for example from an OOM kill during ticket analysis, `orchestrator/analyze.mts:70-85`), or when a project's dispatch.sh backgrounds a job.
- **Requested fix:** Don't discard ownership of a pass group while it still has live members. Either keep it recorded (for example a list of owned groups in the lock that `cancelTick` and lock reclaim honour, so no new pass starts over it and `off`/uninstall cancel it), or treat the leftover as part of the finished pass and terminate that group alone with the same SIGTERM, grace, SIGKILL sequence, logging and recording it. If you terminate it, document why this is not a pass timeout: the pass leader has already exited. In both cases, log the leftover and mark the project result with a reason. Never touch other groups. Update the tick and tick-lock header comments and the cancellation paragraph in `docs/factory-cli.md`.
- **Verification:** A synthetic dispatcher backgrounds a non-detached `sleep` and starts a detached "ticket" child, then exits 0. Assert that the leftover is either still recorded and cancelled by `schedule off`, or terminated by the tick, with the reason in state.json. Assert that the detached ticket child survives, and that the next tick doesn't start a pass while the leftover group is unrecorded and alive.

### 3. Failed enable and partial installation are not tested through the production adapter and stub

- **Where:**
  - In `cli/test/schedule-linux.test.mts`, failures are injected only for `show` (`:159`, `:571`), `disable --now` (`:183`, `:504`) and `stop factory-tick.service` (`:188`, `:504`, `:625`).
  - Failed `enable --now`, a failed `daemon-reload` during `on`, the second artifact failing, and repeated `on` are covered only by the in-memory `FakeSchedule` (`cli/test/scheduler.test.mts:49-80`).
- **Failure:** No repository test proves the production command construction and error reporting for these steps. The ticket's tests clause asks for "the stateful service-manager stub ... Inject failed enable, stop and cancellation". TESTING.md asks the stub to "inject failures at relevant lifecycle steps, including partial installation and enablement" and for coverage of "repeated enable/disable, repair". Old finding 10 asked for exactly this production-adapter coverage. P-A and P-B show the behaviour is currently right, so this is a missing regression test, not wrong behaviour.
- **Requested fix:** Add CLI tests against the stub (real `cli/bin/factory.mts`, production `SystemdSchedule`). Use P-A and P-B in `/recovery/evidence/review-0/probes.test.mts` as a starting point:
  - (a) `once:--user enable --now factory-tick.timer` fails. Expect exit != 0, an error naming the stub's observed state, both units ledgered, no enabled member in `schedule.json`, and an exact call list. A retry `schedule on` then succeeds with exact calls and no duplicate ledger entries.
  - (b) `once:--user daemon-reload` fails during `on`. Both units are ledgered, the timer isn't enabled, and uninstall removes both by exact identity.
  - (c) `schedule on` run twice gives the exact repeated calls, and the stub rejects nothing.
- **Verification:** The new tests pass. Breaking `enable()` or the ledgering order in the production adapter makes them fail. Rerun the full suite.

### 4. Docs conflict with the current cancellation contract and the slice status

- **Where:**
  - `TESTING.md:47` (the approved policy text) says synthetic subprocess tests show "Factory's disable/removal logic does not itself kill an active pass". The approved contract now has off and uninstall cancel the owned pass, and the repo-specific section (`TESTING.md:69` onward) doesn't reconcile the two.
  - `docs/factory-cli.md:4` still says "Later slices remain proposed", while the same file documents the implemented Linux scheduler.
- **Failure:** A later agent reading TESTING.md could take the policy literally and "fix" off so it stops cancelling the pass, or write tests expecting the pass to survive. AGENTS.md and the ticket require these docs to stay accurate.
- **Requested fix:** Leave the policy text itself unchanged. In "In this repository", add one sentence: under the approved #30/#33 contract, off, uninstall and reinstall cancel the tick's own dispatcher group, and the tests prove that this cancellation is confined to that group and that independently detached ticket runs survive. Correct the `docs/factory-cli.md` status line for slice four. Keep unslop rules (no em dashes).
- **Verification:** Read the docs. `diff` of TESTING.md's policy section against `/recovery/testing-policy.md` shows only the appended repo-specific lines.

## Accepted deviations and observations (not findings)

- **The tick visits every opted-in project in registry order**, where the ticket says "at most the first enabled project". This is what the original commit did, the prior verifiers accepted it, #34 extends traversal, and the docs say rotation is #34. The per-project manager gate and the abort check make sure no later project starts after off. I accept it. The re-review should not require narrowing it.
- **The `ScheduleBackend` shape differs from the plan.** `install(spec, record)` ledgers each unit as it is written, and `status()` returns `{timer, enabled, tick, lastTick?}`. This meets the ledger-ordering and separate-observation requirements. The full status contract is #37.
- **#32's merged interface is `reserveRun`, with no protocol marker or exit code 78.** The `copyProblem` check uses that actual interface, as instructed. `FACTORY_SCHEDULED=1` is passed but the current dispatcher ignores it, and the docs say so.
- **One test was retired.** "Global switch defaults off, persists" tested `setScheduler`, which the approved contract retires. Its replacements (launch config holds PATH and Node only, and a leftover `scheduler.json` is ignored) are appropriate. No required contract test was weakened. All 7 original `scheduler.test.mts` behaviours still have coverage.
- **A residual race in #32's design:** the dispatcher spawns a detached run and then calls `reserveRun` synchronously. A group SIGTERM that lands between those two calls leaves the run alive (preserved) but without its reservation until the run writes its own record. With the timer already disabled, no scheduled pass can overfill in that gap. #33 adds nothing that clears records or reservations.
- **Cosmetic carry-overs:** a pass killed by a signal is still recorded as exit 128 (`runDispatchSh`), and a newline in a saved path would still inject a unit line (outside the characters the ticket lists).
- **Orchestration log:** `/recovery/run.log` shows "Implementation reports BLOCKED; human review needed", but the current `implementation.md` says "No BLOCKED decision", and the `run.mjs` pattern `^Status:\s*(?:\*\*)?BLOCKED` doesn't match it. I treated the implementation report as complete and not blocked.

## Old FAIL findings mapped to the current tree

| Old finding | Status now | Evidence |
| --- | --- | --- |
| 1. Uninstall did not commit `enabled=false` and killed the pass | Replaced by the approved contract. Uninstall runs `disable --now` on the timer, then stops the service, cancels and confirms, and only then removes files. There is no local flag. Detached runs survive. The residual gap is finding 2 (an owned group can go unrecorded). | `schedule-linux.test.mts` "cli: install -> ... -> uninstall" (exact calls), "cancellation that cannot be confirmed ...", "dry-run uninstall ..." |
| 2. Reinstall left the scheduler enabled | Fixed: it stops and cancels first, rewrites the owned units, and leaves the timer disabled. | "reinstall stops scheduling ..." |
| 3. Manual tick inherited terminal stdin | Deferred by the user. Inherited stdin is kept and documented, and the unit relies on systemd's default stdin. | README, tick.mts header |
| 4. Failed enable did not roll back the local switch | Replaced: no local switch exists. A failed enable keeps the ledger and reports the observed state (P-A). Stub-level test coverage is missing (finding 3). | `scheduler.test.mts` (Fake), P-A |
| 5. Opt-in skipped the origin and executable checks | Fixed. | "cli: opt-in refusals ..." , `schedule.test.mts` "opt-in needs an origin ..." |
| 6. Tick exited 0 on a failed pass | Fixed: exit 1, and the timer is untouched. | "a branch change skips ...; a failed pass fails the tick but never the timer" |
| 7. Missing `--max 3` and `FACTORY_SCHEDULED=1` | Fixed. A caller override of `SANDCASTLE_STATE_DIR` also loses. | e2e CLI test, `scheduler.test.mts` "the scheduled pass gets --max 3 ..." |
| 8. No `--project <name\|path>` | Fixed. A positional project is rejected. | "cli: argument contract ..." |
| 9. No state.json or pass pid | Fixed: running before spawn, pid at spawn, result and duration after, interrupted without invented times. | state assertions in several tests |
| 10. No production-adapter contract tests | Mostly fixed: adapter and CLI tests against a stateful stub that rejects unexpected calls. Enable, daemon-reload and repeated-on failure coverage is still missing (finding 3). | `schedule-linux.test.mts` |
| Low: config shape, state dir override, duplicated spawn | Fixed: `schedule.json {version,path,node}`, `p.state` always, and the tick spawns through `runDispatchSh(SpawnOptions)`. | code and tests |

## What I checked and found correct

- No local global boolean anywhere. A legacy `scheduler.json` is ignored. `schedulingState` needs the timer enabled and active, and a query failure is unknown and fails closed. Tested and probed (P-E).
- `on` writes the service and then the timer, ledgering each as it is written, then runs `daemon-reload` and `enable --now factory-tick.timer`. The service is never enabled.
- `off` runs `disable --now factory-tick.timer`, then `stop factory-tick.service`, then `cancelTick`. Failing either of the first two stops before any signal.
- Cancellation signals only the recorded tick pid and `-pass pgid`, after checking start time. It refuses group 1 and Factory's own group. SIGTERM, a 30 s grace and SIGKILL apply only after cancellation starts, and a pass running normally is never timed out. A failed confirmation keeps the lock and runtime files, and a retry works.
- The tick checks the manager before the lock, after it and before every project, and checks for abort again before spawning. A racing tick does no work. A dead tick's live pass group blocks a new pass.
- Units: `Type=oneshot`, `TimeoutStartSec=infinity`, `KillMode=process`, `TimeoutStopSec=2min`, journal output, quoted Environment and ExecStart lines (`%` and `$` handled), no shell or profile. Timer: `OnActiveSec=1min`, `OnUnitInactiveSec=5min`, `Persistent=false`. The manifest accepts only exact unit and path pairs.
- Docs: README, ADAPTING, SKILL, `docs/factory-cli.md` and the header comments of touched files describe the code accurately, except for finding 4. No em dashes were added.

## Limitations

- The stub is a command boundary, not systemd. These remain trusted and unproven: timer firing and rearming (including after a failed tick, a tick exiting 143, or a `failed` unit), `systemctl stop` blocking until the tick exits, signal delivery under `KillMode=process`, leftover processes in the cgroup between ticks, journald, `StandardInput=null`, and `XDG_RUNTIME_DIR` being available for the tick's own `systemctl --user show` calls. Finding 1 rests on systemd's documented stop semantics. I didn't simulate them.
- Process-identity checks rely on `/proc` (Linux). macOS is #35 and wasn't exercised.
- I didn't rerun the implementor's mutation script. I read its output (13 mutations, each caught by at least one test) and spot-checked the tests it names.
- I made no changes to the worktree, git refs, tracker, host services or credentials. The only files I wrote are under `/recovery/evidence/review-0/` and this report.
