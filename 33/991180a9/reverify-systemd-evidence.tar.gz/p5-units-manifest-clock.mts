// P5 module-level probes against the real branch code (imported from the checkout, nothing modified):
//  - schedulerUnits() quoting for space/quote/backslash/percent/dollar (+ newline, informational) checked by
//    unitparse.py against systemd's DOCUMENTED quoting grammar; directive inspection.
//  - manifest validate(): exact unit/path pairs only, no prefix acceptance.
//  - tick() with an injected clock and synthetic passes (no real time, no real dispatch).
// Run: node p5-units-manifest-clock.mts <repo>
import { execFileSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, realpathSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const repo = process.argv[2];
const { schedulerUnits } = await import(join(repo, 'cli/src/platform/systemd.mts'));
const { validate } = await import(join(repo, 'cli/src/manifest.mts'));
const { paths } = await import(join(repo, 'cli/src/paths.mts'));
const { tick } = await import(join(repo, 'cli/src/tick.mts'));
const { addProject } = await import(join(repo, 'cli/src/projects.mts'));
const { setScheduler, setProjectSchedule } = await import(join(repo, 'cli/src/schedule.mts'));
let checks = 0, defects = 0;
const expect = (name: string, ok: boolean, detail = '') => { checks++; if (!ok) defects++; console.log(`CHECK ${ok ? 'OK    ' : 'DEFECT'} : ${name}${detail ? `  [${detail}]` : ''}`); };
const tmp = realpathSync(mkdtempSync(join(tmpdir(), 'p5-')));
const decode = (text: string) => { const f = join(tmp, 'unit'); writeFileSync(f, text); return execFileSync('python3', ['-I', new URL('./unitparse.py', import.meta.url).pathname, f], { encoding: 'utf8' }).split('\n').filter(Boolean); };

console.log('=== unit quoting');
const nasty = { node: `/opt/my node/"q"/50%/$HOME/back\\slash/node`, factory: `/h/a b/$USER%n/"x"/cli/bin/factory.mts`, path: `/p/$PATH:/s p/%h:/q"t`, home: `/home/u %i/$x"y` };
const u = schedulerUnits(nasty);
console.log(u['factory-tick.service']);
const lines = decode(u['factory-tick.service']);
console.log(lines.join('\n'));
expect('no unsafe specifier/variable expansion in generated service', !lines.some(l => l.startsWith('UNSAFE')));
expect('ExecStart decodes to [node, factory.mts, schedule, tick] exactly', JSON.stringify(lines.filter(l => l.startsWith('EXEC:')).map(l => l.slice(5))) === JSON.stringify([nasty.node, nasty.factory, 'schedule', 'tick']));
expect('Environment decodes to exact saved PATH and FACTORY_HOME', JSON.stringify(lines.filter(l => l.startsWith('ENV:')).map(l => l.slice(4))) === JSON.stringify([`PATH=${nasty.path}`, `FACTORY_HOME=${nasty.home}`]));
const nl = schedulerUnits({ ...nasty, path: '/bin\nExecStartPre=/bin/evil' })['factory-tick.service'];
console.log(`INFO         : newline in PATH yields a separate directive line: ${/^ExecStartPre=/m.test(nl)} (out of the ticket's listed characters; informational)`);

console.log('=== directives');
const svc = schedulerUnits({ node: '/usr/bin/node', factory: '/a/cli/bin/factory.mts', path: '/usr/bin', home: '/h' });
const S = svc['factory-tick.service'], T = svc['factory-tick.timer'];
const dir = (t: string) => t.split('\n').filter(l => /^[A-Za-z]+=/.test(l));
console.log('service directives:', dir(S)); console.log('timer directives:', dir(T));
expect('Type=oneshot', /^Type=oneshot$/m.test(S));
expect('TimeoutStartSec=infinity (no finite start timeout)', /^TimeoutStartSec=infinity$/m.test(S) && !/^Timeout(Stop|)Sec=/m.test(S) && !/^RuntimeMaxSec=/m.test(S));
expect('KillMode=process', /^KillMode=process$/m.test(S));
expect('no shell / profile / EnvironmentFile sourcing', !/EnvironmentFile|bash|\/sh\b|-lc|source |\.profile|\.bashrc/.test(dir(S).join('\n')));
expect('output to journal (no StandardOutput/StandardError override => journal default)', !/^Standard(Output|Error)=/m.test(S) || /^StandardOutput=journal$/m.test(S));
expect('stdin not attached to a TTY (no StandardInput=tty*)', !/^StandardInput=tty/m.test(S));
expect('service has no [Install] (only the timer is enabled)', !/^\[Install\]/m.test(S));
expect('timer OnActiveSec=1min', /^OnActiveSec=1min$/m.test(T));
expect('timer OnUnitInactiveSec=5min', /^OnUnitInactiveSec=5min$/m.test(T));
expect('timer has no OnBootSec/OnCalendar/RandomizedDelaySec/AccuracySec', !/^(OnBootSec|OnStartupSec|OnCalendar|RandomizedDelaySec|AccuracySec)=/m.test(T));
expect('timer Persistent=false (no catch-up replay)', /^Persistent=false$/m.test(T));
expect('timer WantedBy=timers.target', /^WantedBy=timers.target$/m.test(T));
expect('no image build / credential / login in units', !/docker|build|login|credential|token/i.test(dir(S).join('\n') + dir(T).join('\n')));

console.log('=== manifest exact identity');
const p = paths(tmp);
const cases: [string, any, boolean][] = [
  ['board ok', { kind: 'systemd', unit: 'factory-board.service', path: p.systemd }, true],
  ['tick service ok', { kind: 'systemd', unit: 'factory-tick.service', path: p.tickService }, true],
  ['tick timer ok', { kind: 'systemd', unit: 'factory-tick.timer', path: p.tickTimer }, true],
  ['timer unit with service path', { kind: 'systemd', unit: 'factory-tick.timer', path: p.tickService }, false],
  ['service unit with board path', { kind: 'systemd', unit: 'factory-tick.service', path: p.systemd }, false],
  ['board unit with timer path', { kind: 'systemd', unit: 'factory-board.service', path: p.tickTimer }, false],
  ['prefix lookalike factory-evil.service', { kind: 'systemd', unit: 'factory-evil.service', path: join(p.home, '.config/systemd/user/factory-evil.service') }, false],
  ['prefix lookalike at board path', { kind: 'systemd', unit: 'factory-evil.service', path: p.systemd }, false],
  ['missing unit name', { kind: 'systemd', path: p.systemd }, false],
  ['proto key __proto__', { kind: 'systemd', unit: '__proto__', path: p.systemd }, false],
  ['launchd tick label (macOS later)', { kind: 'launchd', label: 'com.factory.tick', path: p.launchd }, false],
];
for (const [name, entry, want] of cases) { let ok = true; try { validate(p, entry); } catch { ok = false; } expect(`validate ${name} => ${want ? 'accepted' : 'rejected'}`, ok === want); }

console.log('=== tick with injected clock and synthetic passes');
const git = (cwd: string, ...a: string[]) => execFileSync('git', ['-c', 'user.name=t', '-c', 'user.email=t@e', ...a], { cwd, stdio: 'ignore' });
const mk = (n: string) => { const r = join(tmp, 'w', n); mkdirSync(join(r, '.sandcastle'), { recursive: true }); git(r, 'init', '-q', '-b', 'main'); git(r, 'commit', '-q', '--allow-empty', '-m', 'i'); writeFileSync(join(r, '.sandcastle/dispatch.sh'), '#!/bin/sh\n', { mode: 0o755 }); addProject(p, r); setProjectSchedule(p, r, true); return r; };
mk('a'); mk('b');
setScheduler(p, true);
let clock = 1_000_000; const lines2: string[] = []; const seen: string[] = [];
const r1 = await tick(p, { now: () => clock, log: l => lines2.push(l), pass: async (proj: any) => { seen.push(proj.name); clock += proj.name === 'a' ? 125_000 : 7_000; return proj.name === 'a' ? 2 : 0; } });
console.log(lines2.join('\n')); console.log(JSON.stringify(r1));
expect('passes visited sequentially in registry order', JSON.stringify(seen) === '["a","b"]');
expect('pass durations from the injected clock (125s, 7s), tick 132s', lines2.includes('pass a: exit 2 after 125s') && lines2.includes('pass b: exit 0 after 7s') && lines2.some(l => l.endsWith(', 132s')));
expect('tick result reports the failing pass (ticket: nonzero on project error)', r1.result !== 'done', `result=${r1.result}`);
// Overlap guard: a tick while another holds the lock.
let release!: () => void; const hold = new Promise<void>(r => (release = r));
const t1 = tick(p, { now: () => clock, log: () => {}, pass: async () => { await hold; return 0; } });
await new Promise(r => setTimeout(r, 50));
const r2 = await tick(p, { now: () => clock, log: () => {}, pass: async () => 0 });
expect('a second concurrent tick does not run passes', r2.result === 'busy');
release(); await t1;
rmSync(tmp, { recursive: true, force: true });
console.log(`P5 SUMMARY: ${checks} checks, ${defects} defects`);
