#!/usr/bin/env bash
# P4 reinstall contract, project opt-in validation, branch drift, CLI argument contract, tick exit status.
source /home/agent/evidence/33/reverify-systemd-boundary/lib.sh
enabled() { grep -o '"enabled": [a-z]*' "$HOME/.config/factory/scheduler.json" 2>/dev/null || echo absent; }

echo "=== A. reinstall while the scheduler is on"
fresh p4-a; mkproj alpha; F install >/dev/null 2>&1; F project add "$W/work/alpha" >/dev/null; F schedule on alpha >/dev/null; F schedule on >/dev/null
mark; step install; since; info "stub state:"; unitstate
expect "reinstall leaves desired disabled (ticket: stop future activation, desired disabled)" test "$(enabled)" = '"enabled": false'
expect "reinstall disables the tick timer" bash -c "grep -q '\"disable\",\"--now\",\"factory-tick.timer\"' <<<'$(since)'"
expect "reinstall keeps the project opt-in" grep -q '"branch": "main"' "$HOME/.config/factory/projects.json"
step schedule status

echo; echo "=== B. project opt-in validation"
fresh p4-b; F install >/dev/null 2>&1
mkproj old old; mkproj det; mkproj loc; mkproj noexec; mkproj gone; mkproj noremote
for n in old det loc noexec gone noremote; do F project add "$W/work/$n" >/dev/null; done
step schedule on old; expect "old dispatcher protocol refused" test $? -ne 0
g -C "$W/work/det" checkout -q --detach; step schedule on det; expect "detached HEAD refused" test $? -ne 0
g -C "$W/work/loc" checkout -q -b local-only; step schedule on loc; rc=$?
expect "branch not on origin refused (ticket: named branch available on origin)" test $rc -ne 0
chmod -x "$W/work/noexec/.sandcastle/dispatch.sh"; step schedule on noexec; rc=$?
expect "non-executable dispatch.sh refused (ticket: executable dispatch.sh)" test $rc -ne 0
g -C "$W/work/noremote" remote remove origin; step schedule on noremote; rc=$?
expect "project without any origin refused" test $rc -ne 0
step schedule on gone; rm -rf "$W/work/gone"; step schedule off gone
expect "project off works for a deleted checkout (registry only)" grep -q '"enabled":false' <(jq_ "$HOME/.config/factory/projects.json" 'v.projects.find(x=>x.name==="gone").schedule')
expect "project off retains the branch" grep -q '"branch":"main"' <(jq_ "$HOME/.config/factory/projects.json" 'v.projects.find(x=>x.name==="gone").schedule')
g -C "$W/work/det" checkout -q main; step schedule on det
g -C "$W/work/det" checkout -q -b feat; g -C "$W/work/det" push -q origin feat 2>/dev/null; step schedule on det
expect "repeated project on refreshes saved branch" grep -q '"branch":"feat"' <(jq_ "$HOME/.config/factory/projects.json" 'v.projects.find(x=>x.name==="det").schedule')

echo; echo "=== C. branch drift blocks the tick without touching the checkout"
fresh p4-c; mkproj alpha; F install >/dev/null 2>&1; F project add "$W/work/alpha" >/dev/null; F schedule on alpha >/dev/null; F schedule on >/dev/null
g -C "$W/work/alpha" checkout -q -b other; echo dirty > "$W/work/alpha/untracked.txt"; g -C "$W/work/alpha" stash list > /dev/null
before=$(projsnap alpha); F schedule tick < /dev/null 2>&1 | tee "$W/t.out"
expect "tick skips a project on a different branch" grep -q 'skip alpha: checkout is on other, scheduled branch is main' "$W/t.out"
expect "no pass ran" test -z "$(ls "$W/rec")"
expect "checkout unchanged (HEAD, branch, status, refs, files)" test "$before" = "$(projsnap alpha)"
expect "no stash created" test -z "$(g -C "$W/work/alpha" stash list)"
g -C "$W/work/alpha" checkout -q --detach main; before=$(projsnap alpha); F schedule tick < /dev/null 2>&1 | tee "$W/t2.out"
expect "tick skips a detached HEAD" grep -q 'detached HEAD' "$W/t2.out"
expect "detached checkout unchanged" test "$before" = "$(projsnap alpha)"

echo; echo "=== D. failed pass: tick exit status and no timer disable"
g -C "$W/work/alpha" checkout -q main; rm -f "$W/work/alpha/untracked.txt"; echo 3 > "$W/ctl/alpha.exit"
mark; F schedule tick < /dev/null > "$W/t3.out" 2>&1; rc=$?; cat "$W/t3.out"; echo "[tick exit $rc]"
expect "tick makes no systemctl call (never disables the timer after a failed pass)" test -z "$(since)"
expect "timer still enabled in stub after the failed pass" "$NODE" -e 'process.exit(JSON.parse(require("fs").readFileSync(process.argv[1])).units["factory-tick.timer"].enabled?0:1)' "$STUB_DIR/state.json"
expect "global switch still on after failed pass" test "$(enabled)" = '"enabled": true'
expect "tick returns nonzero on project error (ticket)" test $rc -ne 0

echo; echo "=== E. CLI argument contract"
for args in "schedule on --project alpha" "schedule off --project alpha" "schedule status --project alpha" "schedule status --project alpha --json" \
            "schedule on --json" "schedule off alpha --json" "schedule" "schedule bogus" "schedule on alpha extra" "schedule tick --max 9" "schedule status extra"; do
  F $args > "$W/cli.out" 2>&1; rc=$?; echo "\$ factory $args  -> exit $rc: $(head -c 200 "$W/cli.out" | tr '\n' ' ')"
  eval "rc_$(echo "$args" | tr -c 'a-z0-9' '_')=$rc"
done
expect "--project accepted for schedule on (ticket: schedule on|off|status [--project <name|path>])" test "$rc_schedule_on___project_alpha_" -eq 0
expect "--project accepted for schedule status" test "$rc_schedule_status___project_alpha_" -eq 0
expect "--json rejected except for status" test "$rc_schedule_on___json_" -ne 0 -a "$rc_schedule_off_alpha___json_" -ne 0
expect "missing/unknown subcommand rejected" test "$rc_schedule_" -ne 0 -a "$rc_schedule_bogus_" -ne 0
expect "extra args rejected" test "$rc_schedule_on_alpha_extra_" -ne 0 -a "$rc_schedule_status_extra_" -ne 0
expect "tick takes no public dispatch flags" test "$rc_schedule_tick___max_9_" -ne 0
echo; echo "P4 SUMMARY: $CHECKS checks, $DEFECTS defects"
