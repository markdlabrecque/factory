#!/usr/bin/env bash
# Shared fixture helpers for the #33 re-verification probes. Every fixture lives under $E/fixtures/<probe>; HOME and
# FACTORY_HOME point there; PATH starts with test-owned stubs (systemctl, loginctl, docker). The host has no
# systemctl at all, so no call can fall through to a real service manager.
set -u
E=/home/agent/evidence/33/reverify-systemd-boundary
REPO=${REPO:-/home/agent/workspace}
NODE=$(command -v node)
BASEPATH="$E/stub:$(dirname "$NODE"):/usr/local/bin:/usr/bin:/bin"
CHECKS=0; DEFECTS=0
ok()     { CHECKS=$((CHECKS+1)); echo "CHECK OK     : $*"; }
defect() { CHECKS=$((CHECKS+1)); DEFECTS=$((DEFECTS+1)); echo "CHECK DEFECT : $*"; }
expect() { local what=$1; shift; if "$@"; then ok "$what"; else defect "$what"; fi; }
info()   { echo "INFO         : $*"; }

fresh() { # fresh <probe-name>: new fixture, exports env
  W=$E/fixtures/$1; rm -rf "$W"; mkdir -p "$W/home" "$W/stubstate" "$W/rec" "$W/work"
  export HOME=$W/home FACTORY_HOME=$W/home STUB_DIR=$W/stubstate STUB_UNIT_DIR=$W/home/.config/systemd/user
  export PATH=$BASEPATH
  unset SANDCASTLE_STATE_DIR FACTORY_SCHEDULED
  : > "$STUB_DIR/calls.jsonl"
  echo "### fixture $W"
}
F() { "$NODE" "$REPO/cli/bin/factory.mts" "$@"; }
step() { echo; echo "\$ factory $*"; F "$@" 2>&1; local rc=$?; echo "[exit $rc]"; return $rc; }
calls() { "$NODE" -e 'for (const l of require("fs").readFileSync(process.argv[1],"utf8").split("\n").filter(Boolean)) { const c = JSON.parse(l); console.log(JSON.stringify(c.argv) + (c.rejected ? "  REJECTED " + c.rejected : c.injectedFailure ? "  INJECTED-FAILURE" : c.error ? "  ERROR " + c.error : "")); }' "$STUB_DIR/calls.jsonl"; }
mark() { CALLMARK=$(wc -l < "$STUB_DIR/calls.jsonl"); }
since() { tail -n +$((CALLMARK+1)) "$STUB_DIR/calls.jsonl" | "$NODE" -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{for(const l of s.split("\n").filter(Boolean)){console.log(JSON.stringify(JSON.parse(l).argv))}})'; }
unitstate() { cat "$STUB_DIR/state.json" 2>/dev/null; }
jq_() { "$NODE" -e 'const v=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")); const f=new Function("v","return "+process.argv[2]); console.log(JSON.stringify(f(v)))' "$1" "$2"; }
g() { git -c user.name=t -c user.email=t@example.com "$@"; }

# mkproj <name> [current=yes|old] : a synthetic Git project with a bare origin and a recording fake dispatch.sh.
# The fake dispatcher records cwd, argv, PATH, state dir, FACTORY_SCHEDULED, stdin target and TTY-ness to
# $W/rec/<name>.<n>.log. Control files: $W/ctl/<name>.sleep (seconds), .exit (code), .detach (spawn a setsid child).
mkproj() {
  local n=$1 cur=${2:-yes} r=$W/work/$1
  mkdir -p "$r/.sandcastle" "$W/ctl"; g init -q --bare "$W/work/$n-origin.git"
  g -C "$W/work" init -q -b main "$n" >/dev/null; g -C "$r" commit -q --allow-empty -m init
  g -C "$r" remote add origin "$W/work/$n-origin.git"; g -C "$r" push -q origin main 2>/dev/null
  cat > "$r/.sandcastle/dispatch.sh" <<EOF
#!/usr/bin/env bash
k=\$(ls "$W/rec" | grep -c "^$n\\.") ; out="$W/rec/$n.\$k.log"
{ echo "pid=\$\$"; echo "cwd=\$PWD"; printf 'argv=%s\n' "\$(printf '[%s]' "\$@")"; echo "PATH=\$PATH"
  echo "SANDCASTLE_STATE_DIR=\${SANDCASTLE_STATE_DIR-<unset>}"; echo "FACTORY_SCHEDULED=\${FACTORY_SCHEDULED-<unset>}"
  echo "stdin=\$(readlink /proc/self/fd/0)"; if [ -t 0 ]; then echo "stdin_tty=yes"; else echo "stdin_tty=no"; fi
  echo "env_keys=\$(env | cut -d= -f1 | sort | tr '\n' ' ')"; } > "\$out"
if [ -f "$W/ctl/$n.detach" ]; then setsid sleep 300 </dev/null >/dev/null 2>&1 & echo "detached=\$!" >> "\$out"; fi
echo "[fake dispatch.sh $n] started pid \$\$"
sleep "\$(cat "$W/ctl/$n.sleep" 2>/dev/null || echo 0)"
echo "finished=yes" >> "\$out"
exit "\$(cat "$W/ctl/$n.exit" 2>/dev/null || echo 0)"
EOF
  chmod +x "$r/.sandcastle/dispatch.sh"
  if [ "$cur" = yes ]; then echo 'reserveRun(iid, pid);' > "$r/.sandcastle/dispatch.mts"; echo 'export function reserveRun() {}' > "$r/.sandcastle/board.mts"
  else echo 'spawn();' > "$r/.sandcastle/dispatch.mts"; : > "$r/.sandcastle/board.mts"; fi
  g -C "$r" add -A; g -C "$r" commit -q -m scaffold; g -C "$r" push -q origin main 2>/dev/null
}
# projsnap <name>: HEAD, branch, porcelain status and file hashes, to prove Factory touched nothing in the project.
projsnap() { local r=$W/work/$1; echo "HEAD=$(g -C "$r" rev-parse HEAD) branch=$(g -C "$r" symbolic-ref -q --short HEAD || echo DETACHED) status=[$(g -C "$r" status --porcelain | tr '\n' ';')] refs=$(g -C "$r" for-each-ref --format='%(refname)=%(objectname)' | md5sum | cut -c1-12) files=$(cd "$r" && find . -path ./.git -prune -o -type f -print0 | sort -z | xargs -0 md5sum | md5sum | cut -c1-12)"; }

# The service's command line and environment, read from the generated factory-tick.service using systemd's
# documented quoting (C-style escapes in "...", %% -> %, and in ExecStart $$ -> $). This decodes OUR unit text to run
# the tick the way the unit specifies; it does not emulate systemd's process manager.
unit_exec() { python3 -I "$E/unitparse.py" "$HOME/.config/systemd/user/factory-tick.service"; }
# run_tick_as_unit [stdin-source]: runs ExecStart with only the unit's Environment= (+ HOME, which the user manager sets).
run_tick_as_unit() {
  local -a cmd envs; mapfile -t lines < <(unit_exec)
  envs=(); cmd=()
  for l in "${lines[@]}"; do case $l in ENV:*) envs+=("${l#ENV:}");; EXEC:*) cmd+=("${l#EXEC:}");; esac; done
  env -i HOME="$HOME" "${envs[@]}" "${cmd[@]}"
}
