#!/usr/bin/env bash
# P1 tracer bullet: real CLI + production Systemd backend against the stateful systemctl stub.
# install -> project opt-in -> global on -> tick (run as the unit specifies) -> status -> off -> uninstall.
source /home/agent/evidence/33/reverify-systemd-boundary/lib.sh
fresh p1
chmod +x "$E/stub/systemctl"
mkdir -p "$STUB_UNIT_DIR"; echo '[Service]' > "$STUB_UNIT_DIR/unrelated.service"   # someone else's unit
mkproj alpha; mkproj bravo

mark; step install
info "systemctl calls during install:"; since
expect "fresh install leaves scheduler off (no enabled config)" bash -c "! grep -q '\"enabled\": true' '$HOME/.config/factory/scheduler.json' 2>/dev/null"
expect "install writes no tick units" test ! -e "$STUB_UNIT_DIR/factory-tick.timer" -a ! -e "$STUB_UNIT_DIR/factory-tick.service"
step project add "$W/work/alpha"; step project add "$W/work/bravo"
SA=$(projsnap alpha); SB=$(projsnap bravo)

mark; step schedule on alpha
expect "project opt-in makes no systemctl call (starts no units)" test -z "$(since)"
expect "project opt-in leaves global switch off" bash -c "! grep -q '\"enabled\": true' '$HOME/.config/factory/scheduler.json' 2>/dev/null"
expect "saved branch main recorded for alpha" grep -q '"branch": "main"' "$HOME/.config/factory/projects.json"

mark; (cd "$W/work/alpha" && step schedule on)   # cwd inside a checkout: must still be the GLOBAL switch
info "systemctl calls for global on:"; since
expect "global on: exactly daemon-reload then enable --now factory-tick.timer" test "$(since | tr -d '\n')" = '["--user","daemon-reload"]["--user","enable","--now","factory-tick.timer"]'
expect "global on inside a checkout did not opt bravo in" bash -c "[ \"\$(grep -c '\"branch\"' '$HOME/.config/factory/projects.json')\" = 1 ]"
info "stub unit state:"; unitstate
expect "stub: timer enabled+active, service not enabled" "$NODE" -e 'const s=JSON.parse(require("fs").readFileSync(process.argv[1])).units; process.exit(s["factory-tick.timer"].enabled&&s["factory-tick.timer"].active&&!s["factory-tick.service"]?.enabled?0:1)' "$STUB_DIR/state.json"
echo "--- manifest"; cat "$HOME/.local/share/factory/manifest.json"
expect "manifest: tick service recorded before timer, each once" test "$(jq_ "$HOME/.local/share/factory/manifest.json" 'v.entries.map(e=>e.unit||e.kind).join(",")')" = '"dir,file,factory-board.service,factory-tick.service,factory-tick.timer"'
echo "--- scheduler config ($HOME/.config/factory/)"; ls -la "$HOME/.config/factory/"; cat "$HOME/.config/factory/scheduler.json"
expect "contract config path p.config/schedule.json exists" test -f "$HOME/.config/factory/schedule.json"
expect "global config saves PATH and absolute node (contract {version,enabled,path,node})" grep -q '"node"' "$HOME/.config/factory/scheduler.json" "$HOME/.config/factory/schedule.json"
echo "--- factory-tick.service"; cat "$STUB_UNIT_DIR/factory-tick.service"
echo "--- factory-tick.timer"; cat "$STUB_UNIT_DIR/factory-tick.timer"
echo "--- decoded ExecStart/Environment (documented quoting)"; unit_exec

echo; echo "=== tick, run exactly as the unit specifies (env -i + unit Environment=, stdin </dev/null as systemd's default)"
run_tick_as_unit < /dev/null > "$W/tick1.out" 2>&1; rc=$?; cat "$W/tick1.out"; echo "[tick exit $rc]"
R=$(ls "$W"/rec/alpha.*.log | head -1); echo "--- fake dispatcher record"; cat "$R"
expect "dispatch cwd is the project root" grep -qx "cwd=$W/work/alpha" "$R"
SAVED_PATH=$(unit_exec | sed -n 's/^ENV:PATH=//p')
expect "dispatch sees the saved PATH" grep -qxF "PATH=$SAVED_PATH" "$R"
expect "dispatch SANDCASTLE_STATE_DIR is p.state" grep -qx "SANDCASTLE_STATE_DIR=$HOME/.local/state/factory" "$R"
expect "dispatch stdin non-TTY (unit default stdin)" grep -qx "stdin_tty=no" "$R"
expect "dispatch argv includes --max 3 (ticket: --max 3)" grep -qx "argv=\[--max\]\[3\]" "$R"
expect "dispatch env FACTORY_SCHEDULED=1 (ticket)" grep -qx "FACTORY_SCHEDULED=1" "$R"
expect "bravo (not opted in) got no pass" test -z "$(ls "$W"/rec/ | grep '^bravo\.')"
expect "tick wrote scheduler/state.json (contract: running/result state + pid)" test -f "$HOME/.local/state/factory/scheduler/state.json"

echo; echo "=== tick with a TTY on stdin (e.g. 'factory schedule tick' typed in a terminal): does Factory ignore stdin?"
rm -f "$W"/rec/*; script -qec "env -i HOME=$HOME FACTORY_HOME=$HOME PATH=$SAVED_PATH $NODE $REPO/cli/bin/factory.mts schedule tick" /dev/null > "$W/tick-tty.out" 2>&1
cat "$W/tick-tty.out"; R2=$(ls "$W"/rec/alpha.*.log | head -1); cat "$R2"
expect "Factory spawns dispatch with stdin ignored even when the tick has a TTY (ticket: stdin ignored)" grep -qx "stdin_tty=no" "$R2"

echo; echo "=== status"
mark; step schedule status; step schedule status --json
info "status calls:"; since
expect "status --json has scheduler.phase/cap/intervalMs (initial contract fields)" grep -q '"cap"' <(F schedule status --json 2>&1)

echo; echo "=== off"
mark; step schedule off; info "off calls:"; since
expect "off: show timer LoadState then disable --now factory-tick.timer, never stops the service" test "$(since | tr -d '\n')" = '["--user","show","factory-tick.timer","--property=LoadState"]["--user","disable","--now","factory-tick.timer"]'
expect "off persisted enabled=false" grep -q '"enabled": false' "$HOME/.config/factory/scheduler.json"
run_tick_as_unit < /dev/null 2>&1 | tee "$W/tick-off.out"
expect "tick with scheduler off runs no pass" grep -q 'scheduler is off' "$W/tick-off.out"

echo; echo "=== uninstall with the scheduler ON (dry-run first)"
step schedule on >/dev/null
TREE() { (cd "$W/home" && find . -print0 | sort -z | xargs -0 ls -ld --time-style=+%s 2>/dev/null | md5sum); }
before=$(TREE); cfgbefore=$(md5sum < "$HOME/.config/factory/scheduler.json")
mark; step uninstall --dry-run
expect "dry-run makes no systemctl calls" test -z "$(since)"
expect "dry-run changes no files" test "$before" = "$(TREE)"
mark; step uninstall; info "uninstall calls:"; since
expect "uninstall commits global enabled=false (ticket: first commits enabled=false)" grep -q '"enabled": false' "$HOME/.config/factory/scheduler.json"
expect "uninstall removed tick units, board unit" test ! -e "$STUB_UNIT_DIR/factory-tick.timer" -a ! -e "$STUB_UNIT_DIR/factory-tick.service" -a ! -e "$STUB_UNIT_DIR/factory-board.service"
expect "uninstall left unrelated.service" test -f "$STUB_UNIT_DIR/unrelated.service"
expect "uninstall never addressed unrelated.service" bash -c "! grep -q unrelated '$STUB_DIR/calls.jsonl'"
expect "config/registry kept" test -f "$HOME/.config/factory/projects.json"
expect "uninstall order: timer removed before tick service before board" test "$(since | grep -o 'factory-[a-z]*\.[a-z]*' | uniq | tr '\n' ' ')" = "factory-tick.timer factory-tick.service factory-board.service "
UC=$(since); if grep -q '"stop","factory-tick.service"' <<<"$UC"; then info "uninstall issues systemctl stop factory-tick.service (a running tick gets SIGTERM under KillMode=process; see P3)"; else info "uninstall did not stop factory-tick.service"; fi
expect "project alpha untouched" test "$SA" = "$(projsnap alpha)"
expect "project bravo untouched" test "$SB" = "$(projsnap bravo)"
mark; step uninstall
expect "repeat uninstall: no manifest, no systemctl calls" test -z "$(since)"
echo; echo "=== all systemctl calls (exact argv)"; calls
echo; echo "P1 SUMMARY: $CHECKS checks, $DEFECTS defects"
