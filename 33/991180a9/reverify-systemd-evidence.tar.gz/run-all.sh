#!/usr/bin/env bash
# Reproduces every output in out/. Usage: ./run-all.sh [repo checkout, default /home/agent/workspace]
set -u; cd "$(dirname "$0")"; export REPO=${1:-/home/agent/workspace}; mkdir -p out
(cd "$REPO" && node --test orchestrator/*.test.mts board/*.test.mts cli/test/*.test.mts) > out/01-repo-tests.tap 2>&1; echo "exit $?" >> out/01-repo-tests.tap
./p1-lifecycle.sh > out/p1-lifecycle.txt 2>&1
./p2-failures.sh > out/p2-failures.txt 2>&1
./p3-preserve.sh > out/p3-preserve.txt 2>&1
./p4-reinstall-optin-cli.sh > out/p4-reinstall-optin-cli.txt 2>&1
node p5-units-manifest-clock.mts "$REPO" > out/p5-units-manifest-clock.txt 2>&1
cat fixtures/*/stubstate/calls.jsonl | grep -c rejected > out/stub-rejected-count.txt
grep -h "SUMMARY" out/p*.txt
