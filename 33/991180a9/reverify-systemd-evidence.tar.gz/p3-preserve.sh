#!/usr/bin/env bash
# P3 Factory's own process handling: off / uninstall during an executing pass with a detached child.
# Synthetic processes only. The stub does NOT deliver signals; where systemd's documented `stop` behaviour matters
# (KillMode=process: SIGTERM to the service's main process only) we send that one signal ourselves and observe what
# FACTORY's tick code then does. That signal step is the trusted systemd semantic, not a claim about real systemd.
source /home/agent/evidence/33/reverify-systemd-boundary/lib.sh
alive() { kill -0 "$1" 2>/dev/null; }
waitfile() { for _ in $(seq 100); do [ -n "$(ls $1 2>/dev/null)" ] && return 0; sleep 0.1; done; return 1; }
start_tick() { ( exec_tick ) > "$W/tick.out" 2>&1 & TICK=$!; }
exec_tick() { local -a envs=() cmd=(); while IFS= read -r l; do case $l in ENV:*) envs+=("${l#ENV:}");; EXEC:*) cmd+=("${l#EXEC:}");; esac; done < <(unit_exec); exec env -i HOME="$HOME" "${envs[@]}" "${cmd[@]}" < /dev/null; }
setup() {
  fresh "p3-$1"; mkproj alpha; mkproj bravo
  F install >/dev/null 2>&1; F project add "$W/work/alpha" >/dev/null; F project add "$W/work/bravo" >/dev/null
  F schedule on alpha >/dev/null; F schedule on bravo >/dev/null; F schedule on >/dev/null
  echo 6 > "$W/ctl/alpha.sleep"; touch "$W/ctl/alpha.detach"
}

echo "=== A. schedule off while alpha's pass runs (pass holds 6s, spawns a detached child)"
setup a; start_tick
waitfile "$W/rec/alpha.*.log"; sleep 0.3
R=$(ls "$W"/rec/alpha.*.log); PASS=$(sed -n 's/^pid=//p' "$R"); DET=$(sed -n 's/^detached=//p' "$R")
info "tick pid=$TICK pass pid=$PASS detached pid=$DET"
mark; step schedule off; since
expect "off issued no stop/kill of factory-tick.service" bash -c "! grep -q 'factory-tick.service' <<<'$(since)'"
expect "pass still alive right after off" alive "$PASS"
expect "detached child alive right after off" alive "$DET"
wait $TICK; rc=$?; cat "$W/tick.out"; echo "[tick exit $rc]"
expect "the held pass ran to completion" grep -qx finished=yes "$R"
expect "no later project (bravo) started after off" test -z "$(ls "$W"/rec | grep '^bravo\.')"
expect "tick logged bravo skipped because the scheduler is off" grep -q 'skip bravo: scheduler is off' "$W/tick.out"
expect "detached child survives the tick's exit" alive "$DET"
kill "$DET" 2>/dev/null

echo; echo "=== A2. project off for alpha while its pass runs; bravo still runs afterwards"
setup a2; start_tick
waitfile "$W/rec/alpha.*.log"; sleep 0.3; R=$(ls "$W"/rec/alpha.*.log); PASS=$(sed -n 's/^pid=//p' "$R"); DET=$(sed -n 's/^detached=//p' "$R")
mark; step schedule off alpha; expect "project off makes no systemctl call" test -z "$(since)"
expect "alpha's pass still alive after project off" alive "$PASS"
wait $TICK; cat "$W/tick.out"
expect "alpha's pass completed" grep -qx finished=yes "$R"
kill "$DET" 2>/dev/null

echo; echo "=== B. uninstall while alpha's pass runs"
setup b; start_tick
waitfile "$W/rec/alpha.*.log"; sleep 0.3
R=$(ls "$W"/rec/alpha.*.log); PASS=$(sed -n 's/^pid=//p' "$R"); DET=$(sed -n 's/^detached=//p' "$R")
info "tick pid=$TICK pass pid=$PASS detached pid=$DET"
mark; step uninstall | grep -E 'Removing|rror'; UC=$(since); echo "$UC"
info "global switch after uninstall: $(grep -o '"enabled": [a-z]*' "$HOME/.config/factory/scheduler.json")"
expect "uninstall committed enabled=false before removing units" grep -q '"enabled": false' "$HOME/.config/factory/scheduler.json"
expect "uninstall does not stop factory-tick.service (would end the executing tick)" bash -c "! grep -q '\"stop\",\"factory-tick.service\"' <<<'$UC'"
info "stub delivered no signal; pass alive=$(alive $PASS && echo yes || echo no) detached alive=$(alive $DET && echo yes || echo no)"
info "Now applying the documented effect of 'systemctl stop factory-tick.service' with KillMode=process: SIGTERM to the main PID ($TICK) only."
kill -TERM "$TICK"; wait $TICK; rc=$?; cat "$W/tick.out"; echo "[tick exit $rc]"; sleep 0.3
expect "Factory's tick leaves the executing pass running after SIGTERM (ticket: preserve an executing pass)" bash -c "kill -0 $PASS 2>/dev/null || grep -qx finished=yes '$R'"
expect "detached child survives (Factory does not kill it)" alive "$DET"
expect "no later project started" test -z "$(ls "$W"/rec | grep '^bravo\.')"
kill "$PASS" "$DET" 2>/dev/null

echo; echo "P3 SUMMARY: $CHECKS checks, $DEFECTS defects"
