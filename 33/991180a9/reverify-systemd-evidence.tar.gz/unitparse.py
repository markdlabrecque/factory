# Decodes ExecStart= and Environment= from a generated unit using systemd's DOCUMENTED quoting rules
# (systemd.service(5) "Command lines", systemd.unit(5) "Specifiers", systemd.exec(5) Environment=):
#  - words split on whitespace; "..." quotes; inside quotes C-style escapes \\ and \" (and \n etc.)
#  - specifiers: %% is a literal %, any other %X is a specifier systemd would expand (reported as UNSAFE)
#  - ExecStart only: $$ is a literal $, $NAME / ${NAME} would be expanded (reported as UNSAFE)
# Prints EXEC:<arg> lines and ENV:<NAME=value> lines; UNSAFE:<reason> when the text would not round-trip.
# This is a check of Factory's escaping against the documented grammar, not an emulation of systemd.
import re, sys

def words(s, execline):
    out, i, n = [], 0, len(s)
    while i < n:
        while i < n and s[i] in ' \t': i += 1
        if i >= n: break
        buf = []
        if s[i] == '"':
            i += 1
            while i < n and s[i] != '"':
                if s[i] == '\\' and i + 1 < n:
                    c = s[i + 1]; buf.append({'n': '\n', 't': '\t', '\\': '\\', '"': '"'}.get(c, '\\' + c)); i += 2
                else: buf.append(s[i]); i += 1
            if i >= n: print('UNSAFE:unterminated quote');
            i += 1
        else:
            while i < n and s[i] not in ' \t': buf.append(s[i]); i += 1
        out.append(spec(''.join(buf), execline))
    return out

def spec(w, execline):
    res, i = [], 0
    while i < len(w):
        c = w[i]
        if c == '%':
            if w[i + 1:i + 2] == '%': res.append('%'); i += 2; continue
            print(f'UNSAFE:specifier %{w[i+1:i+2]} would be expanded'); res.append(c); i += 1; continue
        if execline and c == '$':
            if w[i + 1:i + 2] == '$': res.append('$'); i += 2; continue
            print(f'UNSAFE:variable expansion at {w[i:i+10]!r}'); res.append(c); i += 1; continue
        res.append(c); i += 1
    return ''.join(res)

for line in open(sys.argv[1], encoding='utf8').read().split('\n'):
    if line.startswith('ExecStart='):
        for a in words(line[len('ExecStart='):], True): print('EXEC:' + a)
    elif line.startswith('Environment='):
        for a in words(line[len('Environment='):], False): print('ENV:' + a)
