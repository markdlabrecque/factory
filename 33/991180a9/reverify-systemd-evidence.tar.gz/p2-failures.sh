#!/usr/bin/env bash
# P2 partial failure / repair / exact removal, real CLI + production Systemd backend + failure-injecting stub.
source /home/agent/evidence/33/reverify-systemd-boundary/lib.sh
setup() { fresh "p2-$1"; mkproj alpha; F install >/dev/null 2>&1; F project add "$W/work/alpha" >/dev/null 2>&1; }
ledger() { jq_ "$HOME/.local/share/factory/manifest.json" 'v.entries.map(e=>e.unit||e.kind).join(",")'; }
enabled() { grep -o '"enabled": [a-z]*' "$HOME/.config/factory/scheduler.json" 2>/dev/null || echo "absent"; }

echo "=== A. enable --now factory-tick.timer fails during global on"
setup a
echo "--user enable --now factory-tick.timer" > "$STUB_DIR/fail"
mark; step schedule on; rc=$?; since
expect "global on reports failure (nonzero exit)" test $rc -ne 0
info "desired switch after failed enable: $(enabled)"
expect "desired enabled rolled back to false after enable failure (ticket: roll back desired enabled)" test "$(enabled)" != '"enabled": true'
expect "both units remain ledgered for repair" test "$(ledger)" = '"dir,file,factory-board.service,factory-tick.service,factory-tick.timer"'
step schedule status
rm "$STUB_DIR/fail"; mark; step schedule on; since
expect "repair: schedule on again succeeds, units recorded once each" test "$(ledger)" = '"dir,file,factory-board.service,factory-tick.service,factory-tick.timer"'
mark; step uninstall >/dev/null; since
expect "uninstall after repaired failure removes both tick units" test ! -e "$STUB_UNIT_DIR/factory-tick.service" -a ! -e "$STUB_UNIT_DIR/factory-tick.timer"

echo; echo "=== B. daemon-reload fails after both unit files are written"
setup b
echo "once:--user daemon-reload" > "$STUB_DIR/fail"
mark; step schedule on; rc=$?; since
expect "global on fails" test $rc -ne 0
expect "both written units are ledgered before daemon-reload" test "$(ledger)" = '"dir,file,factory-board.service,factory-tick.service,factory-tick.timer"'
expect "desired switch not turned on when install of units failed" test "$(enabled)" != '"enabled": true'
mark; step uninstall | grep -E 'Removing|Error'; since
expect "uninstall removes both partially-installed units" test ! -e "$STUB_UNIT_DIR/factory-tick.service" -a ! -e "$STUB_UNIT_DIR/factory-tick.timer"

echo; echo "=== C. timer file creation fails after the service was written (second artifact fails)"
setup c
mkdir -p "$STUB_UNIT_DIR"; ln -s "$W/nonexistent-dir/x" "$STUB_UNIT_DIR/factory-tick.timer"   # dangling: write fails ENOENT
mark; step schedule on; rc=$?; since
expect "global on fails" test $rc -ne 0
expect "the first artifact (service) stays ledgered, the failed timer is not" test "$(ledger)" = '"dir,file,factory-board.service,factory-tick.service"'
expect "no enable attempted" bash -c "! grep -q enable <<<'$(since)'"
mark; step uninstall | grep -E 'Removing|Error'; since
expect "uninstall removes the ledgered service" test ! -e "$STUB_UNIT_DIR/factory-tick.service"
expect "uninstall leaves the unowned dangling timer path alone" test -L "$STUB_UNIT_DIR/factory-tick.timer"

echo; echo "=== D. unowned unit files are refused"
setup d
mkdir -p "$STUB_UNIT_DIR"; echo "# someone else's" > "$STUB_UNIT_DIR/factory-tick.timer"
mark; step schedule on; rc=$?
expect "refuses unowned factory-tick.timer, nonzero" test $rc -ne 0
expect "unowned file unchanged" grep -qx "# someone else's" "$STUB_UNIT_DIR/factory-tick.timer"
expect "no systemctl call when refusing" test -z "$(since)"
expect "nothing ledgered" test "$(ledger)" = '"dir,file,factory-board.service"'

echo; echo "=== E. off when disable fails: desired false is committed FIRST"
setup e; F schedule on >/dev/null
echo "--user disable --now factory-tick.timer" > "$STUB_DIR/fail"
mark; step schedule off; rc=$?; since
expect "off reports the failure" test $rc -ne 0
expect "desired enabled=false persisted despite disable failure" test "$(enabled)" = '"enabled": false'
rm "$STUB_DIR/fail"; step schedule status
expect "status shows switch off + timer still active (no false success)" bash -c "F() { $NODE $REPO/cli/bin/factory.mts \"\$@\"; }; F schedule status | grep -q 'Timer: active'"
step schedule off; step schedule off
expect "repeated off is idempotent" test "$(enabled)" = '"enabled": false'

echo; echo "=== F. stop of tick timer fails during uninstall, then repeat uninstall"
setup f; F schedule on >/dev/null
echo "once:--user stop factory-tick.timer" > "$STUB_DIR/fail"
mark; step uninstall | grep -E 'Removing|rror'; since
expect "manifest kept after a failed removal (resumable)" test -f "$HOME/.local/share/factory/manifest.json"
mark; step uninstall | grep -E 'Removing|rror'; since
expect "repeat uninstall completes, tick units gone" test ! -e "$STUB_UNIT_DIR/factory-tick.timer" -a ! -e "$STUB_UNIT_DIR/factory-tick.service" -a ! -e "$HOME/.local/share/factory/manifest.json"

echo; echo "=== G. a ledgered unit file already missing on disk"
setup g; F schedule on >/dev/null; rm "$STUB_UNIT_DIR/factory-tick.timer"
mark; step uninstall | grep -E 'Removing|rror'; since
expect "uninstall tolerates a missing timer and removes the rest" test ! -e "$STUB_UNIT_DIR/factory-tick.service" -a ! -e "$HOME/.local/share/factory/manifest.json"

echo; echo "=== H. board-only manifest (scheduler never enabled)"
setup h
mark; step uninstall | grep -E 'Removing|rror'; since
expect "board-only uninstall touches only factory-board.service" test "$(since | grep -o 'factory-[a-z]*\.[a-z]*' | sort -u | tr '\n' ' ')" = "factory-board.service "

echo; echo "=== I. status when the manager errors or is absent"
setup i; F schedule on >/dev/null
echo "--user show factory-tick.timer --property=LoadState,ActiveState,LastTriggerUSec" > "$STUB_DIR/fail"
step schedule status | tee "$W/st.txt"
expect "manager error => timer 'unknown', not active" grep -q '^Timer: unknown' "$W/st.txt"
rm "$STUB_DIR/fail"
PATH=$(dirname "$NODE"):/usr/bin:/bin step schedule status | tee "$W/st2.txt"
expect "no systemctl on PATH => unknown" grep -q '^Timer: unknown' "$W/st2.txt"
step schedule status --json > "$W/st3.txt"; true
echo "--user show factory-tick.timer --property=LoadState,ActiveState,LastTriggerUSec" > "$STUB_DIR/fail"
F schedule status --json > "$W/st4.json" 2>&1; cat "$W/st4.json" | head -12
expect "--json manager error => timer unknown" grep -q '"timer": "unknown' "$W/st4.json"
echo; echo "=== stub rejected calls across all P2 fixtures (should be none)"
grep -h rejected "$E"/fixtures/p2-*/stubstate/calls.jsonl || echo "(none)"
echo; echo "P2 SUMMARY: $CHECKS checks, $DEFECTS defects"
