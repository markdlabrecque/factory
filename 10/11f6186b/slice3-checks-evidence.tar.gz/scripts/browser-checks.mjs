// Chromium checks of the installed board: isolated polling fixture, then read-only live Factory project comparison.
import { chromium } from '/home/mark/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {spawn,spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync,renameSync,rmSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
const D='/tmp/factory-slice3-checks-20261111', F=D+'/fixtures', O=D+'/browser';
const cli='/home/mark/.local/share/factory/app/cli/bin/factory.mts';
const serverFile='/home/mark/.local/share/factory/app/board/board-server.mts';
const state=F+'/browser-state';rmSync(state,{recursive:true,force:true});mkdirSync(state,{recursive:true});
const env={PATH:F+'/bin:'+dirname(process.execPath)+':/usr/bin:/bin',HOME:F+'/home',FACTORY_HOME:F+'/home',SANDCASTLE_STATE_DIR:state,LANG:'C.UTF-8'};
const checks=[],errors=[];let browser,server,context;
function check(id,ok,detail){checks.push({id,pass:!!ok,detail});console.log(`${ok?'PASS':'FAIL'} ${id}: ${JSON.stringify(detail)}`)}
function record(iid,project,stage,extra={}){const now=new Date().toISOString();const d={iid:String(iid),project,stage,title:`Synthetic slice3 browser ${iid}`,branch:`${iid}-synthetic`,base:'main',pid:process.pid,stageSince:now,startedAt:now,updatedAt:now,...extra};const file=state+'/'+project.replaceAll('/','_')+'--'+iid+'.json';writeFileSync(file+'.tmp',JSON.stringify(d,null,2));renameSync(file+'.tmp',file);return d;}
const first=record(901,'fixture/alpha','implementing',{ticketUrl:'https://example.invalid/issues/901',note:'synthetic initial state'});
record(902,'fixture/alpha','queued',{note:'synthetic waiting dependency'});record(903,'fixture/beta','done',{verdict:'PASS'});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const status=()=>{const r=spawnSync(process.execPath,[cli,'status','--project','alpha','--json'],{cwd:F+'/home',env,encoding:'utf8'});if(r.status!==0)throw Error(r.stderr);return JSON.parse(r.stdout)};
function normalized(runs){return runs.filter(r=>r.project==='fixture/alpha').map(r=>({iid:r.iid,stage:r.stage,branch:r.branch,note:r.note||'',mr:r.mr||''})).sort((a,b)=>a.iid.localeCompare(b.iid));}
try{
 let output='';server=spawn(process.execPath,[serverFile],{cwd:F+'/home',env:{...env,PORT:'0',HOST:'127.0.0.1'},stdio:['ignore','pipe','pipe']});
 server.stdout.on('data',b=>output+=b);server.stderr.on('data',b=>output+=b);
 let url;for(let i=0;i<100;i++){url=/http:\/\/127\.0\.0\.1:\d+/.exec(output)?.[0];if(url)break;await sleep(50)}
 if(!url)throw Error('isolated server did not start: '+output);writeFileSync(O+'/server.txt',output);
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true});
 context=await browser.newContext({viewport:{width:1440,height:1100},recordVideo:{dir:O+'/video',size:{width:1440,height:1100}},reducedMotion:'reduce'});
 const page=await context.newPage();page.on('pageerror',e=>errors.push(String(e)));
 let polls=0,documents=0;page.on('request',req=>{if(req.url().includes('/api/runs'))polls++;if(req.isNavigationRequest()&&req.frame()===page.mainFrame())documents++});
 await page.goto(url,{waitUntil:'networkidle'});
 await page.locator('.card').filter({hasText:'Synthetic slice3 browser 901'}).waitFor();
 const api=await (await fetch(url+'/api/runs')).json(),cliBefore=status();
 writeFileSync(O+'/isolated-api-before.json',JSON.stringify(api,null,2));writeFileSync(O+'/isolated-cli-before.json',JSON.stringify(cliBefore,null,2));
 check('isolated-cli-api-agree',JSON.stringify(normalized(api.runs))===JSON.stringify(normalized(cliBefore.runs)),normalized(cliBefore.runs));
 check('initial-stages-visible',await page.getByText('Implementing',{exact:true}).count()>0 && await page.getByText('Queued',{exact:true}).count()>0,'initial synthetic active/queued cards rendered');
 const filter=page.locator('.project-filter select');await filter.selectOption('fixture/alpha');
 const filteredCount=await page.locator('.card:visible').count();
 check('project-filter',filteredCount===2 && !await page.locator('.card').filter({hasText:'Synthetic slice3 browser 903'}).isVisible(),{expectedAlphaCards:2,actual:filteredCount,betaHidden:!await page.locator('.card').filter({hasText:'Synthetic slice3 browser 903'}).isVisible()});
 const card=page.locator('.card').filter({hasText:'Synthetic slice3 browser 901'});
 await card.locator('a').first().focus();const focused=await page.evaluate(()=>document.activeElement?.getAttribute('href'));
 await page.screenshot({path:O+'/01-isolated-before.png',fullPage:true});
 const navigationBefore=documents,pollsBefore=polls;
 record(901,'fixture/alpha','verifying',{...first,stage:'verifying',stageSince:new Date().toISOString(),updatedAt:new Date().toISOString(),note:'synthetic stage changed by fixture'});
 await card.locator('.status').filter({hasText:'Verifying'}).waitFor({timeout:25000});
 const cliAfter=status(),apiAfter=await(await fetch(url+'/api/runs')).json();
 writeFileSync(O+'/isolated-cli-after.json',JSON.stringify(cliAfter,null,2));writeFileSync(O+'/isolated-api-after.json',JSON.stringify(apiAfter,null,2));
 const renderedStage=await card.locator('.status').innerText();
 const semanticStage=(await card.locator('.status').textContent()).trim();
 check('poll-updates-stage',polls>pollsBefore && semanticStage==='Verifying',{pollsBefore,pollsAfter:polls,renderedStage,semanticStage});
 check('poll-without-reload',documents===navigationBefore,{documentsBefore:navigationBefore,documentsAfter:documents});
 check('poll-preserves-filter-focus',await filter.inputValue()==='fixture/alpha' && await page.evaluate(()=>document.activeElement?.getAttribute('href'))===focused,'filter and focused link survived polling');
 check('updated-cli-api-agree',JSON.stringify(normalized(apiAfter.runs))===JSON.stringify(normalized(cliAfter.runs)),normalized(cliAfter.runs));
 check('updated-note',await card.locator('.note').innerText()==='synthetic stage changed by fixture','new note displayed');
 await page.screenshot({path:O+'/02-isolated-after.png',fullPage:true});
 const newRecord=record(904,'fixture/alpha','done',{verdict:'PASS',mr:'https://example.invalid/pull/904'});
 await page.locator('.card').filter({hasText:'Synthetic slice3 browser 904'}).waitFor({timeout:25000});
 check('poll-adds-card',await page.locator('.card:visible').count()===3,'new done card appeared while alpha filter remained selected');
 await page.screenshot({path:O+'/03-isolated-new-card.png',fullPage:true});
 const browserVersion=browser.version();writeFileSync(O+'/environment.json',JSON.stringify({browser:'Chromium',version:browserVersion,executable:'/usr/bin/chromium',installedServer:serverFile},null,2));
 await context.close();context=null;
 // Live board: read only, and store only this public Factory project's rows (not unrelated projects).
 context=await browser.newContext({viewport:{width:1440,height:1100},reducedMotion:'reduce'});const live=await context.newPage();live.on('pageerror',e=>errors.push(String(e)));
 let liveMatch=false,liveCli,liveApi;
 const liveNorm=rs=>rs.filter(r=>r.project==='markdlabrecque/factory').map(r=>({iid:r.iid,stage:r.stage,branch:r.branch||'',mr:r.mr||''})).sort((a,b)=>a.iid.localeCompare(b.iid));
 for(let n=0;n<3;n++){
  const r=spawnSync(process.execPath,[cli,'status','--project','factory','--json'],{cwd:'/home/mark/Projects/factory',env:{...process.env},encoding:'utf8'});
  writeFileSync(O+'/live-cli-status.stderr',r.stderr);if(r.status!==0)throw Error('live CLI status failed: '+r.stderr);
  liveCli=JSON.parse(r.stdout);liveApi=await(await fetch('http://127.0.0.1:4444/api/runs')).json();
  liveMatch=JSON.stringify(liveNorm(liveCli.runs))===JSON.stringify(liveNorm(liveApi.runs));if(liveMatch)break;await sleep(200);
 }
 writeFileSync(O+'/live-cli-status.json',JSON.stringify(liveCli,null,2));writeFileSync(O+'/live-board-factory-only.json',JSON.stringify({runs:liveApi.runs.filter(r=>r.project==='markdlabrecque/factory'),generatedAt:liveApi.generatedAt},null,2));
 check('live-cli-board-api-agree',liveMatch,{project:'markdlabrecque/factory',rows:liveNorm(liveCli.runs).length,boardService:liveCli.board.service});
 await live.goto('http://127.0.0.1:4444',{waitUntil:'networkidle'});await live.locator('.project-filter select').selectOption('markdlabrecque/factory');
 const visible=await live.locator('.card:visible .proj').allTextContents();check('live-browser-project-filter',visible.length>0 && visible.every(p=>p==='markdlabrecque/factory'),{visibleCards:visible.length,project:'markdlabrecque/factory'});
 check('live-browser-rows',await live.locator('.card:visible').count()===liveNorm(liveApi.runs).length,'rendered Factory card count matches live API');
 await live.screenshot({path:O+'/04-live-factory-only.png',fullPage:true});
 check('browser-no-uncaught-errors',errors.length===0,errors);
}catch(e){check('browser-harness-completed',false,e.stack||String(e));}
finally{
 if(context)await context.close();if(browser)await browser.close();if(server){server.kill('SIGTERM');await new Promise(r=>server.once('exit',r));}
 writeFileSync(D+'/browser-summary.json',JSON.stringify({checks,errors,pass:checks.filter(c=>c.pass).length,fail:checks.filter(c=>!c.pass).length},null,2));
 console.log(JSON.stringify({pass:checks.filter(c=>c.pass).length,fail:checks.filter(c=>!c.pass).length}));
}
