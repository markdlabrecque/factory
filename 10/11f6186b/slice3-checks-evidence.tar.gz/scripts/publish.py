# Publish slice-3 test evidence using the repository's existing temporary-index evidence-branch protocol.
from pathlib import Path
import subprocess,os,json,tarfile,tempfile,shutil,hashlib
D=Path('/tmp/factory-slice3-checks-20261111');ROOT=Path('/home/mark/Projects/factory')
def git(*a,env=None):return subprocess.check_output(['git',*a],cwd=ROOT,env=env,text=True).strip()
sha=git('rev-parse','HEAD');assert sha=='11f6186b4f5a1eeaff1c001aaa94fbfbefab094b'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
report=D/'slice3-checks.md';assert report.exists()
summary=json.loads((D/'installed-summary.json').read_text());assert len(summary['checks'])==42
browser=json.loads((D/'browser-summary.json').read_text());assert browser['pass']==13 and browser['fail']==0
pub=D/'publication';pub.mkdir(exist_ok=True)
shutil.copy2(report,pub/'slice3-checks.md')
for src,dest in [('01-isolated-before.png','slice3-board-before.png'),('02-isolated-after.png','slice3-board-after.png'),('04-live-factory-only.png','slice3-board-live.png')]:shutil.copy2(D/'browser'/src,pub/dest)
archive=pub/'slice3-checks-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name in ['scripts','out','browser','observations','slice3-checks.md','inventory.json','installed-summary.json','installed-first-run-summary.json','browser-summary.json','browser-first-run-summary.json','browser-second-run-summary.json']:
  t.add(D/name,arcname=name)
# No disposable .env, installed fixture trees or Git object stores are published.
with tempfile.TemporaryDirectory(prefix='factory-slice3-evidence-index-') as temp:
 env={**os.environ,'GIT_INDEX_FILE':temp+'/index'}
 files=[pub/n for n in ['slice3-checks.md','slice3-checks-evidence.tar.gz','slice3-board-before.png','slice3-board-after.png','slice3-board-live.png']]
 for attempt in range(3):
  subprocess.run(['git','fetch','--quiet','origin','+refs/heads/sandcastle-evidence:refs/sandcastle/evidence'],cwd=ROOT,check=True)
  parent=git('rev-parse','refs/sandcastle/evidence');git('read-tree',parent,env=env)
  for f in files:git('update-index','--add','--cacheinfo',f'100644,{git("hash-object","-w",str(f))},10/{sha[:8]}/{f.name}',env=env)
  tree=git('write-tree',env=env);commit=git('commit-tree',tree,'-p',parent,'-m',f'#10: Record slice 3 installed CLI and browser acceptance checks at {sha[:8]}')
  r=subprocess.run(['git','push','--quiet','origin',f'{commit}:refs/heads/sandcastle-evidence'],cwd=ROOT)
  if r.returncode==0:
   data={'sourceSha':sha,'commit':commit,'links':{f.name:f'https://github.com/markdlabrecque/factory/blob/{commit}/10/{sha[:8]}/{f.name}' for f in files},'sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
   (D/'published-evidence.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2));break
 else:raise RuntimeError('Evidence push did not fast-forward after three attempts')
