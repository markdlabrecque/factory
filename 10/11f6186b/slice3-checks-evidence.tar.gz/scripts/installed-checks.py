# Slice 3 installed-CLI probes. Disposable homes/projects, strict command stubs, no real ticket launches.
from pathlib import Path
import os,sys,json,subprocess,time,hashlib,signal,pty,select,shutil
D=Path('/tmp/factory-slice3-checks-20261111'); F=D/'fixtures'; O=D/'out'
# Recreate only this harness's disposable fixtures. Run the browser harness after this one, not concurrently.
if F.exists():
 assert not F.is_symlink() and F.resolve().parent==D.resolve()
 shutil.rmtree(F)
CLI=Path('/home/mark/.local/bin/factory').resolve(); ROOT=Path('/home/mark/Projects/factory')
NODE=shutil.which('node'); HOME=F/'home'; BIN=F/'bin'; STATE=HOME/'.local/state/factory'
for p in [HOME,BIN,STATE]:p.mkdir(parents=True,exist_ok=True)
ENV={'PATH':str(BIN)+':'+str(Path(NODE).parent)+':/usr/bin:/bin','HOME':str(HOME),'FACTORY_HOME':str(HOME),'LANG':'C.UTF-8','GIT_CONFIG_COUNT':'1','GIT_CONFIG_KEY_0':'core.hooksPath','GIT_CONFIG_VALUE_0':'/dev/null'}
checks=[]; commands=[]
def check(id,ok,detail):
 checks.append({'id':id,'pass':bool(ok),'detail':detail});print(('PASS ' if ok else 'FAIL ')+id+': '+str(detail),flush=True)
def put(p,s,mode=None):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
 if mode:p.chmod(mode)
def g(p,*args):return subprocess.check_output(['git','-c','user.name=Slice3 fixture','-c','user.email=fixture@example.invalid',*args],cwd=p,env=ENV,text=True,stderr=subprocess.PIPE).strip()
def run(name,args,cwd=None,env=None):
 start=time.monotonic();r=subprocess.run([NODE,str(CLI),*args],cwd=cwd or HOME,env={**ENV,**(env or {})},capture_output=True,text=True,timeout=30)
 put(O/(name+'.stdout'),r.stdout);put(O/(name+'.stderr'),r.stderr)
 commands.append({'name':name,'argv':['factory',*args],'cwd':str(cwd or HOME),'exit':r.returncode,'durationMs':round((time.monotonic()-start)*1000),'stdout':name+'.stdout','stderr':name+'.stderr'})
 return r
# Strict read-only service-manager stub. Every other call is rejected.
put(BIN/'systemctl',f'''#!/usr/bin/env python3
import sys,json,os
from pathlib import Path
p=Path({str(O/'service-calls.jsonl')!r});args=sys.argv[1:]
with p.open('a') as f:f.write(json.dumps(args)+'\\n')
if args!=['--user','show','factory-board.service','--property=LoadState,ActiveState']:
 print('REJECTED '+repr(args),file=sys.stderr);sys.exit(64)
mode=Path({str(F/'manager-mode')!r}).read_text().strip()
if mode=='error':print('synthetic user bus unavailable',file=sys.stderr);sys.exit(1)
print('LoadState='+('not-found' if mode=='missing' else 'loaded'))
print('ActiveState='+('active' if mode=='active' else 'inactive'))
''',0o755)
put(F/'manager-mode','active')
# All potentially external tools are fakes. Preflight requests use a synthetic token, never host credentials.
for name,body in {'gh':'exit 0','glab':'exit 0','claude':'''printf '%s\\n' '{"loggedIn": true}' ''','curl':'printf 400','docker':'if [ "$1" = image ]; then id -u; fi; exit 0','npm':'echo unexpected npm >&2; exit 66','npx':'''printf '%s\\n' "$*" > "$PWD/npx-called"; echo 'synthetic run stdout'; echo 'synthetic run stderr' >&2; exit 4''','journalctl':'echo unexpected journalctl >&2; exit 66'}.items():
 put(BIN/name,'#!/bin/sh\n'+body+'\n',0o755)
projects=[]
def project(name,copy_script=True):
 p=F/name;p.mkdir(exist_ok=True)
 origin=F/(name+'-origin.git');subprocess.run(['git','init','-q','--bare',str(origin)],env=ENV,check=True)
 g(p,'init','-q','-b','main');g(p,'commit','-q','--allow-empty','-m','fixture');g(p,'remote','add','origin',str(origin));g(p,'push','-q','origin','main')
 sc=p/'.sandcastle';sc.mkdir(exist_ok=True);(sc/'logs').mkdir(exist_ok=True);(p/'sub').mkdir(exist_ok=True)
 put(sc/'config.mts',f'export const TRACKER = {{\n kind: "github",\n project: "fixture/{name}",\n}};\nexport const AGENT = {{\n provider: "claude",\n}};\n')
 put(sc/'main.mts','const CONFIG = {\n image: "synthetic-image",\n};\n')
 put(sc/'.env','CLAUDE_CODE_OAUTH_TOKEN=synthetic-not-a-credential\n',0o600)
 (p/'node_modules/@ai-hero/sandcastle').mkdir(parents=True)
 if copy_script:shutil.copy2(ROOT/'orchestrator/dispatch.sh',sc/'dispatch.sh')
 put(sc/'dispatch.mts',"// Synthetic pass: records forwarding only; never invokes a tracker, agent or container.\nimport {writeFileSync} from 'node:fs';\nwriteFileSync('pass-called.json',JSON.stringify({args:process.argv.slice(2),cwd:process.cwd(),state:process.env.SANDCASTLE_STATE_DIR}));console.log('synthetic dispatcher selection: ready=0; no launches');process.exitCode=7;\n")
 projects.append(p);return p
A=project('alpha');B=project('beta');OLD=project('old-copy',False)
shutil.copy2(ROOT/'.sandcastle/dispatch.sh',OLD/'.sandcastle/dispatch.sh')
for name,p in [('alpha',A),('beta',B),('old-copy',OLD)]:
 r=run('register-'+name,['project','add',str(p)]);check('register-'+name,r.returncode==0,'isolated registration')
# A synthetic record writer. Parent PID remains alive throughout these probes.
def record(i,stage,project='fixture/alpha',pid=None,**extra):
 now=time.strftime('%Y-%m-%dT%H:%M:%S.000Z',time.gmtime(time.time()-i))
 p=STATE/(project.replace('/','_')+'--'+str(i)+'.json')
 d={'iid':str(i),'project':project,'title':f'Synthetic slice3 {i}','stage':stage,'stageSince':now,'startedAt':now,'updatedAt':now,'pid':pid or os.getpid(),**extra};put(p,json.dumps(d,indent=2));return p
record(101,'implementing',branch='101-synthetic');record(102,'done',verdict='PASS',mr='https://example.invalid/pr/102');record(103,'verifying',pid=1073741823);record(104,'queued',project='fixture/beta')
r=run('status-json',['status','--project','alpha','--json']);data=json.loads(r.stdout)
check('status-project-filter',r.returncode==0 and {x['iid'] for x in data['runs']}=={'101','102','103'},'selected alpha excludes beta')
check('status-dead-process',next(x for x in data['runs'] if x['iid']=='103')['stage']=='stopped','dead nonterminal record is presented as stopped')
r=run('status-text',['status','--project','alpha']);check('status-text-json',all(x['iid'] in r.stdout and x['stage'] in r.stdout for x in data['runs']) and 'Board: active' in r.stdout,'text and JSON agree')
r=run('lookup-cwd',['status','--json'],A/'sub');check('lookup-subdirectory',json.loads(r.stdout)['project']['root']==str(A),'cwd resolves to alpha root')
r=run('lookup-path',['status','--project',str(B/'sub'),'--json']);check('lookup-explicit-path',json.loads(r.stdout)['project']['root']==str(B),'path inside beta selects beta')
r=run('lookup-unregistered',['status','--json']);check('lookup-unregistered',r.returncode==1 and 'not a registered project' in r.stderr,'outside registry is refused with explanation')
for mode in ['inactive','missing','error']:
 put(F/'manager-mode',mode);r=run('status-'+mode,['status','--project','alpha','--json']);service=json.loads(r.stdout)['board']['service']
 check('status-manager-'+mode,service.startswith('unknown') if mode=='error' else service==mode,service)
put(F/'manager-mode','active')
# Forwarding goes through the REAL installed CLI and REAL current dispatch.sh, with fake prerequisite tools.
r=run('dispatch-dry',['dispatch','--project','alpha','--dry-run','--max','2','--whole-issues']);called=json.loads((A/'pass-called.json').read_text())
check('dispatch-exit',r.returncode==7,'synthetic pass exit code 7 is returned')
check('dispatch-flags-base',called['args']==['--base','main','--dry-run','--max','2','--whole-issues'],called)
check('dispatch-context',called['cwd']==str(A) and called['state']==str(STATE),'root cwd and isolated shared state')
(A/'pass-called.json').unlink();r=run('dispatch-bad-max',['dispatch','--project','alpha','--max','0']);check('dispatch-invalid-before-side-effect',r.returncode==1 and not (A/'pass-called.json').exists(),'bad max rejected before script')
r=run('run-success-path',['run','501','--project','alpha']);forward=(A/'npx-called').read_text().strip();log=A/'.sandcastle/logs/run-501.log'
check('run-exit-and-output',r.returncode==4 and 'synthetic run stdout' in r.stdout and 'synthetic run stderr' in r.stdout,'foreground stream and exit code 4')
check('run-forwarding',forward=='tsx .sandcastle/main.mts --base main --issue 501',forward)
check('run-persisted-log',log.exists() and 'synthetic run stdout' in log.read_text() and 'synthetic run stderr' in log.read_text(),'script output saved to correct run log')
r=run('run-old-copy',['run','501','--project','old-copy']);check('stale-copy-refusal',r.returncode==1 and 'older copy without --issue' in r.stderr and not (OLD/'npx-called').exists(),'actual checkout script copied into isolated project is refused before execution')
check('checkout-copy-is-stale','--issue' not in (ROOT/'.sandcastle/dispatch.sh').read_text(),'local setup gap confirmed, no project files refreshed')
for args in [['run','abc','--project','alpha'],['run','--project','alpha'],['run','1','2','--project','alpha']]:
 r=run('bad-run-'+str(len(commands)),args);check('run-invalid-'+str(len(commands)),r.returncode==1,'invalid ticket/extra positional rejected')
# Retry: branches, logs, evidence and unrelated records survive; guarded states are refused.
failed=record(601,'stopped');g(A,'branch','601-retained');savedlog=A/'.sandcastle/logs/run-601.log';put(savedlog,'retained log\n');evidence=A/'.sandcastle/evidence/601/proof.txt';put(evidence,'retained evidence\n')
r=run('retry-stopped',['retry','601','--project','alpha']);check('retry-clears-only-record',r.returncode==0 and not failed.exists() and savedlog.read_text()=='retained log\n' and evidence.read_text()=='retained evidence\n' and bool(g(A,'branch','--list','601-retained')),'branch/log/evidence preserved')
check('retry-branch-warning','601-retained' in r.stdout and 'skips' in r.stdout,'retained branch prevents dispatch and is named')
for i,stage in [(602,'implementing'),(603,'done'),(604,'queued'),(605,'waiting')]:
 p=record(i,stage);before=p.read_bytes();r=run('retry-'+stage,['retry',str(i),'--project','alpha']);check('retry-refuse-'+stage,r.returncode==1 and p.read_bytes()==before,'refused and record unchanged')
p=record(606,'implementing',pid=1073741823);r=run('retry-dead',['retry','606','--project','alpha']);check('retry-dead-process',r.returncode==0 and not p.exists(),'effective stopped record can be cleared')
r=run('retry-missing',['retry','699','--project','alpha']);check('retry-missing-documented',r.returncode==1 and 'No run record' in r.stderr,'current docs specify refusal; epic historical Q&A expected no-op exit 0')
# Real CLI log selection.
put(A/'.sandcastle/logs/run-701.log','older ticket\n');os.utime(A/'.sandcastle/logs/run-701.log',(1,1));put(A/'.sandcastle/logs/run-702.log','newest ticket\n')
r=run('logs-ticket',['logs','701','--project','alpha']);check('logs-ticket',r.stdout=='older ticket\n','explicit ticket selects exact file')
r=run('logs-newest',['logs','--project','alpha']);check('logs-newest',r.stdout=='newest ticket\n' and 'run-702.log' in r.stderr,'newest file selected and named')
r=run('logs-missing',['logs','799','--project','alpha']);check('logs-missing',r.returncode==1 and 'run-799.log' in r.stderr,'missing log error names expected path')
# Actual terminal Ctrl+C, not an injected AbortSignal. Separate synthetic held process must survive.
held=subprocess.Popen(['sleep','60'],start_new_session=True)
f=A/'.sandcastle/logs/run-703.log';put(f,'initial\n');child,master=pty.fork()
if child==0:
 os.chdir(HOME);os.execve(NODE,[NODE,str(CLI),'logs','703','-f','--project','alpha'],ENV)
out=b''
def until(text,seconds=5):
 global out
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  ready,_,_=select.select([master],[],[],0.1)
  if ready:
   try:out+=os.read(master,65536)
   except OSError:break
  if text.encode() in out:return True
 return False
try:
 check('logs-follow-initial',until('initial'),'initial contents displayed')
 with f.open('a') as w:w.write('appended\n')
 check('logs-follow-append',until('appended'),'new contents displayed')
 put(f,'');time.sleep(.7);put(f,'after truncation\n');check('logs-follow-truncate',until('after truncation'),'starts reading again after truncation')
 os.write(master,b'\x03');deadline=time.monotonic()+5;status=None
 while time.monotonic()<deadline:
  got,status0=os.waitpid(child,os.WNOHANG)
  if got:status=status0;break
  time.sleep(.05)
 check('logs-follow-ctrl-c',status is not None and (os.WIFSIGNALED(status) and os.WTERMSIG(status)==signal.SIGINT or os.WIFEXITED(status) and os.WEXITSTATUS(status)==130),'Ctrl+C terminates follower, not a run')
 check('logs-follow-keeps-held-work',held.poll() is None,'separately held synthetic work remains alive')
 put(O/'logs-pty-output.txt',out.decode(errors='replace'))
finally:
 os.close(master)
 try:os.kill(child,signal.SIGKILL)
 except ProcessLookupError:pass
 held.terminate();held.wait(timeout=5)
# Exploration of epic Q&A guard requirement: report the actual behavior, without launching a real ticket.
for i,stage in [(801,'implementing'),(802,'done')]:
 record(i,stage);r=run('run-record-'+stage,['run',str(i),'--project','alpha']);check('epic-run-record-guard-'+stage,r.returncode!=4,{'expected':'refuse before invoking dispatcher per epic Q&A Q4','actualExit':r.returncode,'dispatcherInvoked':r.returncode==4,'note':'synthetic dispatcher only; source/current installed run wrapper does not inspect run records'})
put(D/'installed-summary.json',json.dumps({'installedCli':str(CLI),'node':subprocess.check_output([NODE,'--version'],text=True).strip(),'sourceSha':g(ROOT,'rev-parse','HEAD'),'checks':checks,'commands':commands},indent=2)+'\n')
print(json.dumps({'pass':sum(c['pass'] for c in checks),'fail':sum(not c['pass'] for c in checks),'total':len(checks)}),flush=True)
